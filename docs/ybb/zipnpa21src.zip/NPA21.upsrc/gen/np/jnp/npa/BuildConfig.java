/** Automatically generated file. DO NOT MODIFY */
package np.jnp.npa;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}