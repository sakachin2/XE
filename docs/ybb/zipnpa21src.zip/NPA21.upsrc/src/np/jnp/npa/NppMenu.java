//CID://+v@@@R~:                                                   //~v@@@I~
package np.jnp.npa;                                                //+v@@@R~

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;



public class NppMenu                                               //~0915R~
{                                                                  //~0915I~
    public static final int  MENU_OPTION=0;                            //~0915I~
    public static final int  MENU_FILE=1;                            //~0915I~
    public static final int  MENU_HELP=2;                           //~0915I~
    public static final int  MENU_CTR=3;                            //~0915I~
    public static final int  DLGID_FILESUBMENU=1;                  //~0A21I~
    public  static String[] strarrayFsubmenu=null;                      //~0A20I~//~0A21R~
	private static String []menuDesc;                            //~0A10R~
	private static int menuId[]={                                 //~0915R~
				MENU_OPTION,                                      //~0915I~//~0A10R~
				MENU_FILE,                                         //~0915I~
				MENU_HELP,                                         //~0915I~
				MENU_CTR}; 
	private static int icons[]={                                   //~0915R~
								android.R.drawable.ic_menu_preferences, //Option,//~0915R~//~0A10R~
								android.R.drawable.ic_menu_save,//FILE//~0915I~
								android.R.drawable.ic_menu_help,
								0							};     //~0915R~
	private NppView nppView;                                       //~0A05I~
	private WnpView wnpView;                                       //~0A05I~
	private ButtonDlg pButtonDlg;                                  //~0A05I~
//***************
                                                   //~0A05I~
//**************                                                   //~0915I~
//**************                                                   //~0A20I~
//**************                                                   //~0A20I~
 public  void init(Menu menu,NppView PnppView)                            //~0914R~//~0915R~//~0A05R~
	{                                                              //~0914I~
        String str;                                                //~0915I~
    //********************                                         //~0A05I~
    	nppView=PnppView;                                          //~0A05I~
        menuDesc=WnpView.contextR.getStringArray(R.array.MenuText); //~0A10I~//~0A20R~
	    strarrayFsubmenu=WnpView.contextR.getStringArray(R.array.FileSubmenuText);//~0A20I~
        for (int ii=0;ii<MENU_CTR;ii++)                                //~0915I~
		{                                                          //~0915I~
        	str=menuDesc[ii];                               //~0915I~
            int id=menuId[ii];                                     //~0915I~
            MenuItem item=menu.add(0,id,0,str);                    //~0915I~
            item.setIcon(icons[ii]);                               //~0915R~
        }                                                          //~0915I~
        wnpView=nppView.wnpView;                                   //~0A05I~
        pButtonDlg=wnpView.pButtonDlg;                             //~0A05I~
    }                                                              //~0914I~
//**************                                                   //~0915I~
//**************                                                   //~0A20I~
//**************                                                   //~0A20I~
 	public  int selected(MenuItem item)                        //~0915R~//~0A19R~//~0A20R~
	{                                                              //~0915I~
        try                                                        //~0A20I~
        {                                                          //~0A20I~
            int itemid=item.getItemId();                               //~0915I~//~0A20R~
                                                                   //~0A20I~
            switch(itemid)                                             //~0915I~//~0A20R~
            {                                                          //~0915I~//~0A20R~
            case    MENU_OPTION:                                      //~0915I~//~0A10R~//~0A20R~
                wnpView.pButtonDlg.OnMenuOption();                     //~0A10I~//~0A19R~//~0A20R~
                break;                                                 //~0915I~//~0A20R~
            case    MENU_FILE:                                         //~0915I~//~0A20R~
//              showDialog(DLGID_FILESUBMENU);                     //~0A21R~
				OnMenuFile();                                      //~0A21I~
                break;                                                //~0915I~//~0A20R~
            case    MENU_HELP:                                         //~0915I~//~0A20R~
                wnpView.pwnp.OnAbout();                                //~0A10I~//~0A20R~
                break;                                                 //~0915I~//~0A20R~
            case    MENU_CTR:                                         //~0915I~//~0A20R~
            }                                                          //~0915I~//~0A20R~
        }                                                          //~0A20I~
		catch(RuntimeException e)                                  //~0A20I~
		{                                                          //~0A20I~
        	e.printStackTrace();                                   //~0A20I~
			System.out.println("NppMenuSelected exception"+e.toString());//~0A20I~
        }                                                          //~0A20I~
        return 0;                                                  //~0915I~
    }//selected                                                    //~0A20R~
////**********************************                             //~0A21R~
////* from onCreateDialog                                          //~0A21R~
////**********************************                             //~0A21R~
//public Dialog MenuOnCreateDialog(Context Pcontext,int Pdlgid)    //~0A21R~
//{                                                                //~0A21R~
//    Dialog pdlg=null;                                            //~0A21R~
//    switch(Pdlgid)                                               //~0A21R~
//    {                                                            //~0A21R~
//    case DLGID_FILESUBMENU:                                      //~0A21R~
//        OnMenuFile();                                            //~0A21R~
//        break;                                                   //~0A21R~
//    default:                                                     //~0A21R~
//    }                                                            //~0A21R~
//    return pdlg;                                                 //~0A21R~
//}                                                                //~0A21R~
//**********************************                               //~0A20I~
//* list file submenu                                              //~0A20I~
//**********************************                               //~0A20I~
private void OnMenuFile()                                          //~0A20I~
{                                                                  //~0A20I~
//    Dialog dlg=new Dialog(WnpView.context);                        //~0A20I~//~0A21R~
//    dlg.setContentView(R.layout.dlgfsub0);                         //~0A20I~//~0A21R~
//    dlg.setTitle(WnpView.context.getText(R.string.FileSubmenuTitle).toString());//~0A20I~//~0A21R~
//                                                                   //~0A20I~//~0A21R~
//    ArrayList<String> arlist=new ArrayList<String>(strarrayFsubmenu.length);//~0A20I~//~0A21R~
//    arlist.addAll(Arrays.asList(strarrayFsubmenu));                //~0A20I~//~0A21R~
//    ArrayAdapter<String> adapter=new ArrayAdapter<String>(WnpView.context,android.R.layout.simple_list_item_1,arlist);//~0A20I~//~0A21R~
//                                                                   //~0A20I~//~0A21R~
//    ListView listview=(ListView)dlg.findViewById(R.id.ListViewFsubmenu);//~0A20I~//~0A21R~
//    listview.setAdapter(adapter);                                  //~0A20I~//~0A21R~
//    listview.setOnItemClickListener(                               //~0A20I~//~0A21R~
//                                new AdapterView.OnItemClickListener()//~0A20I~//~0A21R~
//                                    {                              //~0A20I~//~0A21R~
//                                        public void onItemClick(AdapterView<?> parent,//~0A20I~//~0A21R~
//                                                                View Pview,int Ppos,long Pid)//~0A20I~//~0A21R~
//                                        {                          //~0A20I~//~0A21R~
//                                            getFileSubmenu(Ppos);  //~0A20I~//~0A21R~
//                                        }                          //~0A20I~//~0A21R~
//                                    }                              //~0A20I~//~0A21R~
//                                );                                 //~0A20I~//~0A21R~
//                                                                   //~0A20I~//~0A21R~
//    dlg.show();                                                    //~0A20I~//~0A21R~
                                                                   //~0B02I~
//*******                                                          //~0B02I~
//    AlertDialog.Builder builder=new AlertDialog.Builder(WnpView.context);//~0A21I~//~v@@@I~
//    builder.setTitle(WnpView.context.getText(R.string.FileSubmenuTitle).toString());//~0A21I~//~v@@@I~
//    builder.setPositiveButton("Close",new DialogInterface.OnClickListener()//~0A21I~//~v@@@I~
//                                {                                  //~0A21I~//~v@@@I~
//                                                                   //~0A21I~//~v@@@I~
//                                    public void onClick(DialogInterface dlg,int buttonID)//~0A21I~//~v@@@I~
//                                    {                              //~0A21I~//~v@@@I~
//                                        dlg.dismiss();             //~0A21I~//~v@@@I~
//                                    }                              //~0A21I~//~v@@@I~
//                                }                                  //~0A21I~//~v@@@I~
//                          );                                       //~0A21I~//~v@@@I~
//    builder.setItems(strarrayFsubmenu,                              //~0A21I~//~v@@@I~
//                    new DialogInterface.OnClickListener()          //~0A21I~//~v@@@I~
//                        {                                          //~0A21I~//~v@@@I~
//                            public void onClick(DialogInterface Pdlg,int Pitem)//~0A21I~//~v@@@I~
//                            {                                      //~0A21I~//~v@@@I~
//                                System.out.println("submenu clic itemno="+Pitem);//~0A21I~//~v@@@I~
//                                selectedFileSubmenu(Pitem);        //~0A21I~//~v@@@I~
//                            }                                      //~0A21I~//~v@@@I~
//                        }                                          //~0A21I~//~v@@@I~
//                   );                                              //~0A21I~//~v@@@I~
//    AlertDialog pdlg=builder.create();                              //~0A21I~//~v@@@I~
//    pdlg.show();                                                   //~0A21I~//~v@@@I~
//*******                                                          //~v@@@I~
                                                              //~0B02I~
	AlertDialog.Builder builder=new AlertDialog.Builder(WnpView.context);//~0A21I~
                                                                   //~0B02I~
	ArrayAdapter<String> adapter=new ArrayAdapter<String>(WnpView.context,R.layout.fsubmlr,strarrayFsubmenu);//~0B02I~//~v@@@R~
    ListView listview=new ListView(WnpView.context);                       //~0B02I~
    listview.setAdapter(adapter);                                  //~0B02I~
    FsubmenuList listener=new FsubmenuList();                      //~0B02I~//~v@@@R~
    listview.setOnItemClickListener(listener);                     //~0B02I~
    LinearLayout layout=new LinearLayout(WnpView.context);                 //~0B02I~
    layout.setOrientation(LinearLayout.VERTICAL);                  //~0B02I~
    layout.addView(listview);                                      //~0B02I~
    builder.setView(layout);                                       //~0B02I~
                                                                   //~0B02I~
    builder.setPositiveButton("Close",new DialogInterface.OnClickListener()//~0A21I~
								{                                  //~0A21I~//~v@@@R~
                                                                   //~0A21I~
    								public void onClick(DialogInterface Pdlg,int buttonID)//~0A21I~//~v@@@R~
                                    {                              //~0A21I~
                                    	Pdlg.dismiss();             //~0A21I~//~v@@@R~
                                    }                              //~0A21I~
                                }                                  //~0A21I~
                          );                                       //~0A21I~
    AlertDialog pdlg=builder.create();                              //~0A21I~//~v@@@R~
    pdlg.requestWindowFeature(Window.FEATURE_NO_TITLE);            //~0B02I~
    listener.setDlg(pdlg);                                          //~v@@@I~
    pdlg.show();                                                   //~0A21I~
}//OnMenuFile()                                                    //~0A20I~
//**********************************************************************//~v@@@I~
//*ItemListener class                                              //~v@@@I~
//**********************************************************************//~v@@@I~
class FsubmenuList implements OnItemClickListener
{//~v@@@I~
    private AlertDialog pdlg;                                      //~v@@@I~
	public void setDlg(AlertDialog Pdlg)                           //~v@@@I~
    {                                                              //~v@@@I~
    	pdlg=Pdlg;                                                 //~v@@@I~
    }                                                              //~v@@@I~
                                                                   //~v@@@I~
	public void onItemClick(AdapterView<?> arg0,                   //~v@@@I~
							View arg1, int Ppos, long arg3)        //~v@@@I~
	{                                                              //~v@@@I~
//    	System.out.println("submenu click itemno="+Ppos);          //~v@@@R~
        selectedFileSubmenu(Ppos);                                 //~v@@@I~
        pdlg.dismiss();                                            //~v@@@I~
	}                                                              //~v@@@I~
                                                               //~v@@@I~
}//class FileListSelected                                          //~v@@@I~
//**********************************                               //~0A20I~
//* file submenu selected                                          //~0A21R~
//**********************************                               //~0A20I~
private void selectedFileSubmenu(int Ppos)                              //~0A20I~//~0A21R~
{                                                                  //~0A20I~
	int reqid;                                                     //~0A21I~
//************************                                         //~0A21I~
	switch(Ppos)                                                   //~0A20I~
    {                                                              //~0A20I~
    case 0:          //save                                              //~0A20I~//~0A21R~
    	reqid=CPattern.FILE_SAVE;                                  //~0A21I~
    	break;                                                     //~0A20I~
    case 1:          //load saved                                  //~0A21I~
    	reqid=CPattern.FILE_RELOAD;                                //~0A21I~
    	break;                                                     //~0A21I~
    case 2:          //list score                                  //~0A21I~//~0A24I~
    	reqid=CPattern.FILE_LIST_SCORE;                            //~0A21I~//~0A24M~
    	break;                                                     //~0A21I~//~0A24M~
    case 3:          //old hard->easy                              //~0A21I~//~0A24R~
    	reqid=CPattern.FILE_LIST_LEVEL;                            //~0A21I~//~0A24R~
    	break;                                                     //~0A21I~
    case 4:          //old timeseq                                 //~0A21I~//~0A24I~
    	reqid=CPattern.FILE_LIST_TIMESEQ;                          //~0A21I~//~0A24M~
    	break;                                                     //~0A21I~//~0A24M~
    default:                                                       //~0A20I~
    	return;                                                    //~0A21I~
    }                                                              //~0A20I~
    pButtonDlg.FileSubmenu(reqid);                                 //~0A21R~
}//selectedFileSubmenu                                                  //~0A20I~//~0A21R~
//******************************************************************://~0A20I~
}//class NppMenu                                                         //~0915R~//~0A20R~