package np.jnp.npa;                                                //+2718R~

import android.app.Activity;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;



public class jnp extends Activity {                                //~0914R~
	private NppView nppView;
	private NppMenu nppMenu;//~0914R~
                                     //~0915I~
//**                                                               //~0915I~
    @Override                                                     //~0915I~
    public void onCreate(Bundle icicle)                            //~0914R~
	{                                                              //~0914I~
//    	System.out.println("jnp onCretae");                        //~0C06I~//~0C12R~
    	super.onCreate(icicle);	                                    //~0914R~
    	requestWindowFeature(Window.FEATURE_LEFT_ICON);             //~0914R~//~0915R~//~0A09R~
        nppView=new NppView(this);
        nppMenu=new NppMenu();//~0914I~
        setContentView(nppView);                                   //~0914R~
		this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);//setup menu               //~0915I~//~0A05R~
		this.getWindow().setFeatureDrawableResource(Window.FEATURE_LEFT_ICON,R.drawable.wnp);//~0A09I~
    }                                                              //~0914I~
    @Override                                                      //~0C06I~
    protected void onDestroy()                                     //~0C06I~
	{                                                              //~0C06I~
//    	System.out.println("jnp onDestroy");                       //~0C06I~//~0C12R~
    	super.onDestroy();                                         //~0C06I~
    }                                                              //~0C06I~
//**                                                               //~0915I~
    @Override                                                     //~0915I~
    public boolean onCreateOptionsMenu(Menu menu)                           //~0915I~
	{  
    	super.onCreateOptionsMenu(menu);
    	nppMenu.init(menu,nppView);		//setup menu		               //~0915R~//~0A05R~
    	return true;
	}                                                              //~0915I~
//**                                                               //~0915I~
    @Override                                                     //~0915I~
    public boolean onOptionsItemSelected(MenuItem item)            //~0915I~
	{                                                              //~0915I~
    	nppMenu.selected(item);		//setup menu                   //~0915I~//~0A19R~
    	return true;
	}                                                              //~0915I~
//**                                                               //~0C06I~
    @Override                                                      //~0C06I~
    public void onConfigurationChanged(Configuration Pcfg)         //~0C06I~
	{                                                              //~0C06I~
    	int orientation;                                           //~0C07I~
    	super.onConfigurationChanged(Pcfg);                        //~0C06I~//~0C07M~
//    	System.out.println("jnp configuration changed");           //~0C06I~//~0C12R~
        boolean orichanged=(Pcfg.orientation==Configuration.ORIENTATION_PORTRAIT)!=(Wnp.Sswportrate==true);//~0C06I~
        if (orichanged)                                            //~0C07I~
        	orientation=Pcfg.orientation;                          //~0C07I~
        else                                                       //~0C07I~
        	orientation=0;                                         //~0C07I~
    	nppView.orientationChanged(orientation);                    //~0C06R~//~0C07R~
	}                                                              //~0C06I~
////**************************************                         //~0A21R~
////*by showDialog(id)                                             //~0A21R~
////**************************************                         //~0A21R~
//    @Override                                                    //~0A21R~
//    public Dialog onCreateDialog(int Pid)                        //~0A21R~
//    {                                                            //~0A21R~
//        System.out.println("id="+Pid);                           //~0A21R~
//        Dialog pdlg=nppMenu.MenuOnCreateDialog(this,Pid);        //~0A21R~
//        return pdlg;                                             //~0A21R~
//    }                                                            //~0A21R~
}