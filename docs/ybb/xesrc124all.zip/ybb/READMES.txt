Contains following source directory

  ulib%xever%.tgz         :common library
  xe%xever%.tgz           :xe
  wxe%xever%.tgz          :wxe
  xsub%xever%.tgz         :utility
  xp%xever%.tgz           :xprint
  ulibu%xever%.tgz        :UTF8 version ulib
  xeu%xever%.tgz          :UTF8 version xe
  wxeu%xever%.tgz         :UTF8 version wxe

  gxe%xever%src.tgz       :gxe
  gxeu%xever%src.tgz      :UTF8 version gxe
