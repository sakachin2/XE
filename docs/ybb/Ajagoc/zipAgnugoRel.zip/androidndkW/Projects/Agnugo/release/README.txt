Android porting of gnugo 3.8 for Ajagoc.       2011/05/16
gnugo package is not touched, used as original itself. 

cross compiled by NDK-r5b referencing following web-site. 
  1)www.bekatul.info/content/native-c-application-android
  2)osdir.com/ml/android-ndk/2010-07/msg00606.html

Directory structure
    ** Linux-FC12
    +home3
       +android
       	  +android-sdk-linux_x86 
       +androidndk
          +android-ndk-r5b (NDK package)
          +Projects
              +Agnugo
                  .Makefile
                  .mk.cygwin
                  +jni
                      .Android.mk
                      +gnu-3.8 (expand gnugo tgz)
                           .configure
                            :
                            :
                  +libs
                  +obj

    ** Windows-cygwin
    x:
      +android
          +android-sdk-windows
      +androidndkW
          +android-ndk-r5b (NDK package)
          +Projects
              +Agnugo
                  .Makefile.cygwin
                  .mk.cygwin
                  +jni
                      .Android.mk
                      +gnu-3.8 (expand gnugo tgz)
                           .configure
                            :
                            :
                  +libs
                  +obj

Procedure.

    (1) expand gnugo source package, then "./configure --disable-color && make" 
        Some additional c file will be made. 
        --disable-color is to avoid ncurses linking.
    (2) at the position Makefile is placed, 
        make(Linux) or mk.cygwin(Windows)
    (3) install to emulator("make install")
        After enterer emulator("adb shell"), try "/data/tmp/Agnugo --help".

(Note)
    My terminal is SHARP-is01(API-1.6)
    is01's libm is lacking some function compared with NDK libm,
    so it crashes by "CANNOT LINK EXECUTABLE(__aeabi_fadd is missing).
    I tested only on emulator.
