Jago Version 4.25
Go Viewer and Client
Freeware by R. Grothmann

This is a SGF (smart go format) viewer, and an
IGS/NNGS (internet go server / no name go server)
client for the game of go. For details before
installation see the Jago homepage.

The program is written in Java and needs a Java
runtime environment. This maybe the Internet
Explorer or Sun's Java runtime. The installer
will install icons for both, and an icon for
the HTML documentation.

The Jago home page is on

http://mathsrv.ku-eichstaett.de/MGF/homes/grothmann/jago/Go.html

R. Grothmann
mailto:grothm@ku-eichstaett.de
