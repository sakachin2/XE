package com.Ajagoc.awt;

public interface MouseWheelListener                                //+1213I~
{                                                                  //+1213I~
    public void mouseWheelMoved(MouseWheelEvent e);                //+1213I~
}                                                                  //+1213I~
