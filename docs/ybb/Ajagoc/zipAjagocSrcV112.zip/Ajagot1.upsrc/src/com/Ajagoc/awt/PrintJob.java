package com.Ajagoc.awt;                                                //~1108R~//~1109R~

public class PrintJob                                              //~1215R~
{                                                                  //~1215I~
//**********************                                           //~1128I~
	public PrintJob()                                              //~1215R~
    {                                                              //~1124I~
    }
	public Graphics getGraphics()                                  //~1215I~
    {                                                              //~1215I~
      	return new Graphics();                                     //~1404R~
    }                                                              //~1215I~
	public Dimension getPageDimension()                            //~1215I~
    {                                                              //~1215I~
    	return new Dimension(0,0);                                 //~1215I~
    }                                                              //~1215I~
	public void end()                                              //~1215I~
    {                                                              //~1215I~
    }                                                              //~1215I~
}
