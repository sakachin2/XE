package com.Ajagoc.awt;                                                //~1108R~//~1109R~
//*for GoFrame:Clipboard processing                                //+1401I~
public interface ClipboardOwner                                    //~1212I~
{                                                                  //~1212I~
    public void lostOwnership(Clipboard clipboard, Transferable contents);//~1212I~
}//interface                                                       //~1212R~
