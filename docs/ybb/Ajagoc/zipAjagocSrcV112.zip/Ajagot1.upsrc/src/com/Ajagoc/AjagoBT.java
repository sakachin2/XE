//*CID://+1B1hR~:                             update#=   55;       //+1B1hR~
//**********************************************************************//~v107I~
//1B1h 130513 add help to BTMenu                                   //+1B1hI~
//1102:130123 bluetooth became unconnectable after some stop operation//~v110I~
//1071:121204 partner connection using Bluetooth SPP               //~v107I~
//**********************************************************************//~v107I~
package com.Ajagoc;

import android.content.Intent;
import android.bluetooth.BluetoothSocket;                          //~v107I~

import com.Ajagoc.BT.BTControl;
import com.Ajagoc.awt.Menu;                                        //~v107I~
import com.Ajagoc.awt.MenuBar;
import com.Ajagoc.jagoclient.partner.PartnerFrame;                 //~v107I~
import com.Ajagoc.jagoclient.partner.Server;                       //~v107I~

import jagoclient.Dump;                                            //~v107I~
import jagoclient.Global;
import jagoclient.dialogs.HelpDialog;
import jagoclient.gui.DoActionListener;
import jagoclient.gui.MyMenu;                                      //~v107I~
import jagoclient.gui.MenuItemAction;                              //~v107I~

//********************************************************************//~1212I~
//* Interface to BT                                                //~v107R~
//********************************************************************//~1212I~
public class AjagoBT                                               //~1122R~//~v107R~
		 implements DoActionListener                               //~v107I~
{                                                                  //~1109I~
	private static final String DISCOVERABLE="Make Discoverable";  //~v107M~
	private static final String STARTSERVER="Open Server";         //~v107R~
	private static final String CONNECT="Connect to Server";       //~v107R~
	private static final String BTHELP="BTHelp";                   //+1B1hI~
	private BTControl mBTC;                                        //~v107R~
	private BluetoothSocket mBTSocket;                             //~v107R~
  	private PartnerFrame partnerFrame;                             //~v107I~
    private String mDeviceName;                                    //~v107I~
    private boolean swServer;                                      //~v107I~
//  private static Menu bluetooth;                                 //~v107I~//~v110R~
    private Menu bluetooth;                                        //~v110I~
	public boolean swDestroy;                                      //~v110I~
    public AjagoBT()                                               //~v107R~
    {                                                              //~1329I~
	    mBTC=new BTControl();                                      //~v107R~
    }
    public static AjagoBT createAjagoBT()                          //~v107I~
    {                                                              //~v107I~
		AjagoBT inst=null;                                         //~v107I~
        try                                                        //~v107I~
        {                                                          //~v107I~
		    inst=new AjagoBT();                                    //~v107I~
        }                                                          //~v107I~
        catch(Throwable e)                                         //~v107R~
        {                                                          //~v107I~
            Dump.println(e.toString());                            //~v107R~
        }                                                          //~v107I~
        return inst;                                               //~v107I~
    }                                                              //~v107I~
//********************************************************************//~v107I~
    public void resume()                                           //~v107I~
    {                                                              //~v107I~
        try                                                        //~v107I~
        {                                                          //~v107I~
        	if (mBTC!=null)                                              //~v107I~
			    mBTC.BTResume();                                   //~v107R~
        }                                                          //~v107I~
        catch(Exception e)                                         //~v107R~
        {                                                          //~v107I~
            Dump.println(e,"AjagoBT:resume");                      //~v107I~
            AjagoView.showToast(R.string.failedBluetooth);         //~v107I~
        }                                                          //~v107I~
    }                                                              //~v107I~
//********************************************************************//~v107I~
    public boolean destroy()                                          //~v107I~//~v110R~
    {                                                              //~v107I~
    	boolean rc=false;                                              //~v110I~
    //*************************                                    //~v110I~
        try                                                        //~v107I~
        {                                                          //~v107I~
        	if (mBTC!=null)                                              //~v107I~
            {                                                      //~v110I~
		    	rc=mBTC.BTDestroy();                                  //~v107R~//~v110R~
            }                                                      //~v110I~
            if (mBTSocket!=null)                                   //~@@@2I~//~v110I~
            {                                                      //~@@@2I~//~v110I~
            	rc=true;                                           //~v110I~
				if (Dump.Y) Dump.println("AjagoBT:close mBTSocket="+mBTSocket.toString());//~@@@2I~//~v110I~
            	mBTSocket.close();                                 //~@@@2I~//~v110I~
                mBTSocket=null;                                     //~@@@2I~//~v110I~
            }                                                      //~@@@2I~//~v110I~
        }                                                          //~v107I~
        catch(Exception e)                                         //~v107I~
        {                                                          //~v107I~
            Dump.println(e,"AjagoBT:destroy");                     //~v107I~
            AjagoView.showToast(R.string.failedBluetooth);         //~v107I~
        }                                                          //~v107I~
        return rc;                                                 //~v110I~
    }                                                              //~v107I~
//*************************************************************************//~v107I~
    public void activityResult(int requestCode, int resultCode, Intent data)//~v107I~
    {                                                              //~v107I~
		if (Dump.Y) Dump.println("ABT:destroy");                   //~v110I~
    	swDestroy=true;                                            //~v110I~
        try                                                        //~v107I~
        {                                                          //~v107I~
	    	mBTC.BTActivityResult(requestCode,resultCode,data);    //~v107R~
        }                                                          //~v107I~
        catch(Exception e)                                         //~v107I~
        {                                                          //~v107I~
            Dump.println(e,"AjagoBT:activityResult");              //~v107I~
            AjagoView.showToast(R.string.failedBluetooth);         //~v107I~
        }                                                          //~v107I~
    }                                                              //~v107I~
//********************************************************************//~v107I~
//*from MenuBar;add submenu to mainframe                           //~v107R~
//********************************************************************//~v107I~
    public void addBTMenu(MenuBar Pmenubar)                        //~v107R~
    {                                                              //~v107I~
    	if (bluetooth==null)                                       //~v107I~
        {                                                          //~v107I~
			bluetooth=new MyMenu(Global.resourceString("Bluetooth"));//~v107R~
			bluetooth.add(new MenuItemAction(this,Global.resourceString(STARTSERVER)));//~v107R~
			bluetooth.add(new MenuItemAction(this,Global.resourceString(CONNECT)));//~v107R~
			bluetooth.add(new MenuItemAction(this,Global.resourceString(DISCOVERABLE)));//~v107M~
			bluetooth.add(new MenuItemAction(this,Global.resourceString(BTHELP)));//+1B1hI~
        }                                                          //~v107I~
		Pmenubar.menuList.add(bluetooth);                          //~v107R~
    }                                                              //~v107I~
//********************************************************************//~v107I~
//*implement DoActionListener                                      //~v107R~
//********************************************************************//~v107I~
    @Override                                                      //~v107I~
	public void doAction(String o)                                 //~v107I~
    {                                                              //~v107I~
        try                                                        //~v107I~
        {                                                          //~v107I~
	    	if (mBTC==null)                                        //~v107I~
    	    {                                                      //~v107I~
	        	AjagoView.showToast(R.string.noBTadapter);         //~v107I~
                return;                                            //~v107I~
        	}                                                      //~v107I~
            if (Global.resourceString(DISCOVERABLE).equals(o))     //~v107R~
                setDiscoverable();                                 //~v107R~
            else                                                   //~v107R~
            if (Global.resourceString(STARTSERVER).equals(o))      //~v107R~
                startServer();                                     //~v107R~
            else                                                   //~v107R~
            if (Global.resourceString(CONNECT).equals(o))          //~v107R~
                connect();                                         //~v107R~
            else                                                   //+1B1hI~
            if (Global.resourceString(BTHELP).equals(o))           //+1B1hI~
            {                                                      //+1B1hI~
                new HelpDialog(Global.frame(),"bluetoothAjagoc");  //+1B1hI~
            }                                                      //+1B1hI~
        }                                                          //~v107I~
        catch(Exception e)                                         //~v107I~
        {                                                          //~v107I~
            Dump.println(e,"AjagoBT:doAction");                    //~v107I~
            AjagoView.showToast(R.string.failedBluetooth);         //~v107I~
        }                                                          //~v107I~
    }                                                              //~v107I~
//***************************************************************************//~v107I~
	@Override                                                      //~v107M~
	public void itemAction(String o, boolean flag) {               //~v107M~
	}                                                              //~v107M~
//***************************************************************************//~v107I~
    private void setDiscoverable()                                 //~v107R~
    {                                                              //~v107I~
    	if (Dump.Y) Dump.println("AjagoBT:setDiscoverable");       //~v107I~
        if (mBTC.BTensureDiscoverable(true/*request discoverable if not*/)==0)	//already discoverable//~v107R~
            AjagoView.showToast(R.string.nowDiscoverable);        //~v107I~
    }                                                              //~v107I~
//***************************************************************************//~@@@@I~//~v107M~
    private void startServer()                                     //~v107R~
    {                                                              //~v107I~
    //*******************                                          //~v107I~
    	if (Dump.Y) Dump.println("AjagoBT:startServer");           //~v107I~
        swServer=true;                                             //~v107I~
        mBTSocket=mBTC.BTstartServer();                            //~v107R~
        if (mBTSocket!=null)                                       //~v107I~
        	openServer(mBTSocket);                                 //~v107I~
    }                                                              //~v107I~
//***************************************************************************//~v107I~
    private void connect()                //~@@@@I~                //~v107R~
    {                                                              //~@@@@I~//~v107I~
    	int rc;                                                    //~v107I~
    //**********************                                       //~v107I~
    	if (Dump.Y) Dump.println("AjagoBT:connect");               //~v107I~
        swServer=false;                                            //~v107I~
        rc=mBTC.BTconnect();                                       //~v107R~
        if (rc==1)	//connecting                                   //~v107I~
        {                                                          //~v107I~
			new jagoclient.dialogs.Message(Global.frame(),Global.resourceString("Already_trying_this_connection"));//~v107I~
  			return;                                                //~v107I~
  		}                                                          //~v107I~
    }                                                              //~@@@@I~//~v107I~
//***************************************************************************//~v107I~
//*from BTControl;after request enable completed                   //~v107R~
//***************************************************************************//~v107I~
    public void enabled()                                          //~v107R~
    {                                                              //~v107I~
    	if (Dump.Y) Dump.println("AjagoBT:enabled swServer="+swServer);//~v107R~
        if (swServer)                                              //~v107I~
        {                                                          //~v107I~
		    startServer();                                         //~v107I~
        }                                                          //~v107I~
    }                                                              //~v107I~
//***************************************************************************//~v107I~
//*from BTControl;on MainThread                                    //~v107I~
//***************************************************************************//~v107I~
    public void connected(BluetoothSocket Psocket,String Pdevicename)//~v107I~
    {                                                              //~v107I~
    	if (Dump.Y) Dump.println("AjagoBT:connected swServer="+swServer+",dvice="+Pdevicename);//~v107I~
    	mBTSocket=Psocket;                                         //~v107I~
    	mDeviceName=Pdevicename;                                   //~v107I~
        if (swServer)                                              //~v107I~
        {                                                          //~v107I~
	    	openServer(mBTSocket);                                 //~v107I~
        }                                                          //~v107I~
        else                                                       //~v107I~
        {                                                          //~v107I~
	    	openPartner(mBTSocket,mDeviceName,mBTC.getDeviceName());//~v107R~
        }                                                          //~v107I~
    }                                                              //~v107I~
//***************************************************************************//~v107I~
    private void openServer(BluetoothSocket Psocket)               //~v107I~
    {                                                              //~v107I~
    	if (Dump.Y) Dump.println("AjagoBT:openServer");            //~v107I~
    	new Server(Psocket,mDeviceName,mBTC.getDeviceName());   //open PartnerFrame//~v107R~
    }                                                              //~v107I~
//***************************************************************************//~v107I~
    private void openPartner(BluetoothSocket Psocket,String Pdevicename,String Plocaldevicename)//~v107R~
    {                                                              //~v107I~
  		partnerFrame=new PartnerFrame(Global.resourceString("Connection_to_"),Pdevicename,Plocaldevicename,false,Psocket);//~v107R~
        partnerFrame.connect();                                    //~v107I~
    }                                                              //~v107I~
//***************************************************************************//~v107I~
    public void connectionLost()                           //~v107I~
    {                                                              //~v107I~
    	mBTC.connectionLost();                                     //~v107I~
        if (mBTSocket!=null)                                       //~v110R~
        {                                                          //~v110R~
        	try                                                    //~v110R~
            {                                                      //~v110R~
                if (Dump.Y) Dump.println("AjagoBT connectionLost():close btsocket="+mBTSocket.toString());//~v110R~
    			mBTSocket.close();                                 //~v110R~
            }                                                      //~v110R~
            catch(Exception e)                                     //~v110R~
            {                                                      //~v110R~
	            Dump.println(e,"ABT:connectionLost:close()");      //~v110R~
            }                                                      //~v110R~
            mBTSocket=null;                                        //~v110R~
        }                                                          //~v110R~
    }                                                              //~v107I~
}//class                                                           //~1109R~