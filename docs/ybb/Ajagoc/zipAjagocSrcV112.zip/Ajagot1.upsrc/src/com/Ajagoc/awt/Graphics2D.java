package com.Ajagoc.awt;

import android.graphics.Canvas;

public class Graphics2D extends Graphics                           //+1213R~
{

	public Graphics2D(Canvas PandroidCanvas) {
		super(PandroidCanvas);
	}                                                                  //~1112I~
//*awt.internal but not yet public API                             //~1213I~

	public void setRenderingHint(int keyTextAntialiasing, int i)
	{
	}
}//class                                                           //~1112I~
