package com.Ajagoc.awt;                                                //~1108R~//~1109R~

public class GridBagLayout                                            //~1124R~//~1125R~
{                                                                  //~1111I~
    public GridBagLayout()                                                 //~1111I~//~1124R~//~1125R~
    {                                                              //~1111I~
    }                                                              //~1111I~
  	public void setConstraints(Component comp, GridBagConstraints constraints)//+1215I~
    {                                                              //+1215I~
  	}                                                              //+1215I~
}
