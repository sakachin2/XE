package com.Ajagoc.awt;                                            //~1112I~

                                                             //~1112I~
public class Container extends Component                           //~1116R~
{                                                                  //~1112I~
	public Color backgroundColor=null;                                     //~1216I~
    public Container()                                             //~1118R~
    {                                                              //~1118I~
    	super();                                                   //~1118R~
    }                                                              //~1118I~
    public void doLayout()                                              //~1216I~
    {                                                              //~1216I~
    }                                                              //~1216I~
}//class                                                           //~1112I~
