package com.Ajagoc.awt;

public interface ItemListener                                      //+1124R~
{                                                                  //~1112I~
    void itemStateChanged(ItemEvent e);                          //~1112R~//+1124R~
}                                                                  //~1112I~