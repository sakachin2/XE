//*CID://+dateR~: update#=  85;                                    //~1107R~
//**********************************************************************//~1107I~
package com.Ajagoc;                                         //~1107R~  //~1108R~//~1109R~

//**********************************************************************//~1107I~
public interface AjagoUiThreadI                                    //~1214R~
{                                                                  //~0914I~
	public void runOnUiThread(Object Pany);                        //+1214R~
}//interface AjagoAlertI                                           //~1211R~
