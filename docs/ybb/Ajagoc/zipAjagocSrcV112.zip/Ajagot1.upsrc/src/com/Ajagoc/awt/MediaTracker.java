package com.Ajagoc.awt;                                                //~1108R~//~1109R~

public class MediaTracker                                          //+1417R~
{                                                                  //~1111I~
    public MediaTracker(Frame Pframe)                                     //+1417R~
    {                                                              //~1111I~
    }                                                              //~1111I~
    public void addImage(Image Pimage,int Pid)                     //+1417R~
    {                                                              //~1325I~
    }                                                              //~1325I~
    public void waitForAll()                                       //+1417R~
    {                                                              //~1401I~
    }                                                              //~1401I~
}
