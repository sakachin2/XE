package com.Ajagoc.awt;                                                //~1108R~//~1109R~

import jagoclient.gui.CardPanel;

public class Applet extends Panel                                          //~1124R~//~1125R~//~1325R~
{                                                                  //~1111I~
    public Applet()                                                 //~1111I~//~1124R~//~1125R~
    {                                                              //~1111I~
    }                                                              //~1111I~
    public void add(String Ppos,CardPanel Pcp)                          //~1325I~
    {                                                              //~1325I~
    }                                                              //~1325I~
    public void start()                                            //~1401I~
    {                                                              //~1401I~
    }                                                              //~1401I~
}
