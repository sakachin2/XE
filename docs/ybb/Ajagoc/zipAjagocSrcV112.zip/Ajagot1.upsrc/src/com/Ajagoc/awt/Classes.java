package com.Ajagoc.awt;                                            //~1112I~
//*Document only                                                   //~1216R~
                                                                   //~1216I~
//java.awt                                                         //~1216R~
// Object-->awt.Component-->Container-->Panel-->Applet                      //~1116I~//~1325R~
//                                   -->Window-->Frame             //~1116I~
//                                            -->Dialog            //~1216I~
//                       -->TextComponent-->TextField              //~1216I~
//                                       -- >TextArea                //~1112I~//~1216R~
//                       -->Label                                  //~1216I~
//                       -->Canvas                                 //~1216I~
//                       -->Button                                 //~1217I~
//                       -->Choice                                 //~1219I~
//                       -->List                                   //~1220I~
//                       -->ScrollBar                              //+1401I~
public class Classes                                               //~1216R~
{                                                                  //~1112I~
}//class                                                           //~1112I~
