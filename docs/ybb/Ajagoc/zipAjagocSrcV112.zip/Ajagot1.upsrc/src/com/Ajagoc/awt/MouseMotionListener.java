package com.Ajagoc.awt;

public interface MouseMotionListener
{                                                                  //+1524R~
    public void mouseDragged(MouseEvent e);                        //~1213I~
    public void mouseMoved(MouseEvent e);                          //~1213I~
                                                                   //~1213I~
}                                                                  //~1213I~
