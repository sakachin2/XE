package com.Ajagoc.awt;                                                //~1108R~//~1109R~

public class RenderingHints                                        //~1213R~
{   
//*dummy                                                           //~1213I~
    public final static int  KEY_TEXT_ANTIALIASING  =10;            //~1213R~
    public final static int  VALUE_TEXT_ANTIALIAS_ON  = 1;         //+1213R~
    public final static int  VALUE_TEXT_ANTIALIAS_OFF = 0;         //+1213R~
}
