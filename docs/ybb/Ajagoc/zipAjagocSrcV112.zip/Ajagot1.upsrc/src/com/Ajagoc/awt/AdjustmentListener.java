package com.Ajagoc.awt;

public interface AdjustmentListener                                //~1213R~
{                                                                  //~1112I~
    void adjustmentValueChanged(AdjustmentEvent ev);               //+1213R~
}                                                                  //~1112I~