package com.Ajagoc.awt;                                                //~1108R~//~1109R~
                                                                   //+1212I~
public interface ComponentListener                                 //+1212I~
{                                                                  //+1212I~
    public void componentResized(ComponentEvent e);                //+1212I~
    public void componentMoved(ComponentEvent e);                  //+1212I~
    public void componentShown(ComponentEvent e);                  //+1212I~
    public void componentHidden(ComponentEvent e);                 //+1212I~
}//interface                                                       //~1212R~
