//*CID://+1B10R~: update#= 129;                                    //~v107R~//~v110R~//~1B10R~
//**********************************************************************//~1107I~
//1B10 130501 display ip addr on start server menu item            //~1B10I~
//1102:130123 bluetooth became unconnectable after some stop operation//~v110I~
//1075:121207 control dumptrace by manifest debuggable option      //~v105I~
//1063:121124 menu to display ip address for pertner connection    //~v106I~
//**********************************************************************//~1107I~//~v106M~
package com.Ajagoc;                                         //~1107R~  //~1108R~//~1109R~


import java.net.Inet6Address;
import java.net.InetAddress;                                       //~v106R~
import java.net.NetworkInterface;                                  //~v106R~
import java.util.Enumeration;                                      //~v106I~
import java.text.SimpleDateFormat;
import java.util.Date;

import jagoclient.Dump;

import android.content.Context;                                    //~v107R~
import android.content.pm.ApplicationInfo;                         //~v107R~
import android.content.pm.PackageManager;                          //~v107R~
import android.content.pm.PackageManager.NameNotFoundException;    //~v107R~

import com.Ajagoc.AG;

//**********************************************************************//~1107I~
public class AjagoUtils                                            //~1309R~
{                                                                  //~0914I~
//    static boolean finished=false;                                 //~1309I~//~v110R~
//**********************************                               //~v110I~
//*from Alert,replyed Yes                                          //~v110I~
//**********************************                               //~v110I~
	public static void stopFinish()		//from Alert by Stop:Yes   //~v110I~
    {                                                              //~v110I~
    	if (Dump.Y) Dump.println("AjagoUtils stopFinish");         //~v110I~
        try                                                        //~v110I~
        {                                                          //~v110I~
        	AG.ajagoc.destroyClose();                               //~v110I~
        }                                                          //~v110I~
        catch (Exception e)                                        //~v110I~
        {                                                          //~v110I~
        	Dump.println(e,"stopFinish");                          //~v110I~
            finish();                                              //~v110I~
        }                                                          //~v110I~
    }                                                              //~v110I~
//**********************************                               //~1211I~
	public static void exit(int Pexitcode)                         //~1309I~
    {                                                              //~1309I~
    	if (Dump.Y) Dump.println("AjagoUtils exit() code="+Pexitcode);//~1309I~//~1506R~//~v110R~
		finish();                                                  //~1309R~
    }                                                              //~1309I~
	public static void exit(int Pexitcode,boolean Pkill)           //~1329I~
    {                                                              //~1329I~
    	if (Dump.Y) Dump.println("AjagoUtils kill exit() code="+Pexitcode);//~1506R~//~v110R~
        if (Pkill)                                                 //~1329I~
        {                                                          //~1503I~
    		if (Dump.Y) Dump.println("AjagoUtils kill exit() killProcess");//~v110I~
            Dump.close();                                          //~1503I~
//          System.exit(Pexitcode);                                //~1329I~//~v110R~
			android.os.Process.killProcess(android.os.Process.myPid());//~v110I~
        }                                                          //~1503I~
//      exit(Pexitcode);                                           //~1329I~//~v110R~
    }                                                              //~1329I~
//    public static void finish()                                         //~1309I~//~v110R~
//    {                                                              //~1309I~//~v110R~
//        if (Dump.Y) Dump.println("AjagoUtils finish requested "+finished);//~1506R~//~v110R~
//        if (finished)                                              //~1309M~//~v110R~
//            return ;                                               //~1309M~//~v110R~
//        AG.ajagoc.finish();                                        //~1309I~//~v110R~
//        if (Dump.Y) Dump.println("AjagoUtils context finish request");//~1506R~//~v110R~
//        sleep(1200);//wait subtread termination  1.2sec            //~1503R~//~v110R~
//        if (Dump.Y) Dump.println("AjagoUtils context finish request after sleep 1200");//~1506R~//~v110R~
//        Dump.close();                                              //~1503I~//~v110R~
//        finished=true;                                             //~1309I~//~v110R~
//    }                                                              //~1309I~//~v110R~
//**********************************                               //~@@@@I~//~v110I~
//*from Alert,replyed Yes                                          //~@@@@I~//~v110I~
//**********************************                               //~@@@@I~//~v110I~
    public static void finish()                                    //~@@@@I~//~v110I~
    {                                                              //~@@@@I~//~v110I~
    	if (Dump.Y) Dump.println("AjagoUtils finish");             //~@@@@I~//~v110I~
//        closeFinish();                                             //~@@@@I~//~v110R~
        AG.ajagoc.finish();	//schedule onDestroy                   //~v110I~
    }                                                              //~@@@@I~//~v110I~
//    public static void closeFinish()                               //~@@@@I~//~v110R~
//    {                                                              //~@@@@I~//~v110R~
//        if (Dump.Y) Dump.println("AjagoUtils closeFinish finished="+finished);//~@@@@M~//~v110R~
//        if (finished)                                              //~@@@@I~//~v110R~
//            return ;                                               //~@@@@I~//~v110R~
//        AG.ajagoc.destroyClose();   //close stream the finish      //~@@@@I~//~v110R~
//    }                                                              //~@@@@I~//~v110R~
//    public static void closedFinish()                              //~@@@@I~//~v110R~
//    {                                                              //~@@@@I~//~v110R~
//        if (Dump.Y) Dump.println("AjagoUtils closedFinish finished="+finished);//~@@@@I~//~v110R~
//        if (finished)                                              //~@@@@I~//~v110R~
//            return ;                                               //~@@@@I~//~v110R~
//        AG.ajagoc.finish(); //schedule onDestroy                   //~@@@@I~//~v110R~
//        if (Dump.Y) Dump.println("AjagoUtils context finish request");//~@@@@I~//~v110R~
//        sleep(200);//wait subtread termination  1.2sec             //~@@@@R~//~v110R~
//        if (Dump.Y) Dump.println("AjagoUtils context finish request after sleep 1200");//~@@@@I~//~v110R~
//        Dump.close();                                              //~@@@@I~//~v110R~
//        finished=true;                                             //~@@@@I~//~v110R~
//    }                                                              //~@@@@I~//~v110R~
	public static void sleep(long Pmilisec)                        //~1503I~
    {                                                              //~1503I~
        try                                                        //~1503I~
        {                                                          //~1503I~
        	Thread.sleep(Pmilisec);//wait subtread termination  1.2sec//~1503I~
        }                                                          //~1503I~
        catch(InterruptedException e)                              //~1503I~
		{                                                          //~1503I~
        	Dump.println(e,"sleep interrupted Exception");         //~1503I~
		}                                                          //~1503I~
    }                                                              //~1503I~
//**********************************                               //~1412I~
//*elapsed time calc                                               //~1412I~
//**********************************                               //~1412I~
	public static final int TSID_TITLE_TOUCH=0;                   //~1412I~
	private static final int TSID_MAX        =1;                   //~1412I~
	private static long[] Stimestamp=new long[TSID_MAX];                                 //~1412I~
	public static long setTimeStamp(int Pid)                       //~1412I~
    {                                                              //~1412I~
        if (Pid>=TSID_MAX)                                         //~1412I~
            return 0;                                              //~1412I~
        long t=System.currentTimeMillis();                         //~1412I~
        Stimestamp[Pid]=t;                                         //~1412I~
    	if (Dump.Y) Dump.println("AjagoUtils setTimeStamp id="+Pid+",ts="+Long.toHexString(t));//~1506R~
        return t;                                                  //~1412I~
    }                                                              //~1412I~
	public static int getElapsedTimeMillis(int Pid)                //~1412I~
    {                                                              //~1412I~
        if (Pid>=TSID_MAX)                                         //~1412I~
            return 0;                                              //~1412I~
        if (Stimestamp[Pid]==0)                                    //~1413I~
            return 0;                                              //~1413I~
        long t=System.currentTimeMillis();                         //~1412I~
    	if (Dump.Y) Dump.println("AjagoUtils getElapsed now id="+Pid+",ts="+Long.toHexString(t));//~1506R~
        int  elapsed=(int)(t-Stimestamp[Pid]);                     //~1412I~
    	if (Dump.Y) Dump.println("AjagoUtils getElapsetTimeMillis id="+Pid+",ts="+Integer.toHexString(elapsed));//~1506R~
        Stimestamp[Pid]=0;                                         //~1413I~
        return elapsed;                                            //~1412I~
    }                                                              //~1412I~
//**********************************                               //~1425I~
//*edit date/time                                                  //~1425I~
//**********************************                               //~1425I~
	public static final int TS_DATE_TIME=1;                        //~1425I~
	public static final int TS_MILI_TIME=2;                        //~1425I~
	private static final SimpleDateFormat fmtdt=new SimpleDateFormat("yyyyMMdd-HHmmss");//~1425I~
	private static final SimpleDateFormat fmtms=new SimpleDateFormat("HHmmss.SSS");//~1425I~
	public static String getTimeStamp(int Popt)                    //~1425I~
    {                                                              //~1425I~
        SimpleDateFormat f;                                        //~1425I~
    //**********************:                                      //~1425I~
    	switch(Popt)                                               //~1425I~
        {                                                          //~1425I~
        case TS_DATE_TIME:                                         //~1425I~
        	f=fmtdt;                                               //~1425I~
            break;                                                 //~1425I~
        case TS_MILI_TIME:                                         //~1425I~
        	f=fmtms;                                               //~1425I~
            break;                                                 //~1425I~
        default:                                                   //~1425I~
        	return null;                                           //~1425I~
        }                                                          //~1425I~
        return f.format(new Date());                               //~1425I~
    }                                                              //~1425I~
//**********************************                               //~1425I~
//* Digit Thread ID                                                //~1425I~
//**********************************                               //~1425I~
	public static String getThreadId()                             //~1425I~
    {                                                              //~1425I~
    //**********************:                                      //~1425I~
    	int tid=(int)Thread.currentThread().getId();               //~1425I~
        if (tid<10)                                                //~1425I~
        	return "0"+tid;                                        //~1425I~
        return Integer.toString(tid);                              //~1425I~
    }                                                              //~1425I~
//**********************************                               //~1425I~
	public static String getThreadTimeStamp()                      //~1425I~
    {                                                              //~1425I~
    //**********************:                                      //~1425I~
    	String tidts=getThreadId()+":"+getTimeStamp(TS_MILI_TIME);  //~1425I~
        return tidts;                                              //~1425I~
    }                                                              //~1425I~
//**********************************                               //~v106I~
    public static String getIPAddress()                            //~v106I~
    {                                                              //+1B10I~
    	return getIPAddress(true);                                 //+1B10I~
    }                                                              //+1B10I~
    public static String getIPAddress(boolean Pipv6)               //+1B10I~
    {                                                              //~v106I~
    	String ipa="N/A";                                          //~v106R~
    	String ipv6="";                                           //~v106I~
    //**********************:                                      //~v106I~
        try                                                        //~v106I~
        {                                                          //~v106I~
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();//~v106I~
            while(interfaces.hasMoreElements())                    //~v106I~
            {                                                      //~v106I~
                NetworkInterface network = interfaces.nextElement();//~v106I~
                Enumeration<InetAddress> addresses = network.getInetAddresses();//~v106I~
                while(addresses.hasMoreElements())                 //~v106I~
                {                                                  //~v106I~
                    InetAddress na=addresses.nextElement();        //~v106R~
                    String ipa2=na.getHostAddress();               //~v106I~
                    if (na.isLoopbackAddress()                     //~v106R~
                    ||  na.isLinkLocalAddress()                    //~v106R~
//                  ||  na.isSiteLocalAddress()                    //~v106R~
                    )                                              //~v106I~
                    	continue;                                  //~v106I~
                    if (na instanceof Inet6Address)//ipv6          //~v106M~
                    {                                              //~v106I~
                    	ipv6=ipa2;                                 //~v106I~
                    	continue;                                  //~v106M~
                    }                                              //~v106I~
			        if (Dump.Y) Dump.println("getIPAddress:"+ipa2);//~v106R~
                    ipa=ipa2;                                      //~v106R~
                    break;                                         //~v106R~
                }                                                  //~v106I~
            }                                                      //~v106I~
        }                                                          //~v106I~
        catch(Exception e)                                         //~v106I~
        {                                                          //~v106I~
        	Dump.println(e,"getIPAddress");                        //~v106I~
        }                                                          //~v106I~
        if (!Pipv6 || ipv6.equals(""))                             //+1B10R~
	        return ipa;                                            //~1B10I~
        return ipa+","+ipv6;                                       //~v106R~
    }                                                              //~v106I~
//***********************************************************************//~v107R~
    public static boolean isDebuggable(Context ctx)                //~v107R~
    {                                                              //~v107R~
        PackageManager manager = ctx.getPackageManager();          //~v107R~
        ApplicationInfo appInfo = null;                            //~v107R~
        try                                                        //~v107R~
        {                                                          //~v107R~
            appInfo = manager.getApplicationInfo(ctx.getPackageName(), 0);//~v107R~
        }                                                          //~v107R~
        catch (NameNotFoundException e)                            //~v107R~
        {                                                          //~v107R~
            return false;                                          //~v107R~
        }                                                          //~v107R~
        if ((appInfo.flags & ApplicationInfo.FLAG_DEBUGGABLE) == ApplicationInfo.FLAG_DEBUGGABLE)//~v107R~
            return true;                                           //~v107R~
        return false;                                              //~v107R~
    }                                                              //~v107R~
}//class AjagoUtils                                                //~1309R~
