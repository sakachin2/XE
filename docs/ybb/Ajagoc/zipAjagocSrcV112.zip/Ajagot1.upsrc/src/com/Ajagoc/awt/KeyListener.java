package com.Ajagoc.awt;
import com.Ajagoc.awt.KeyEvent;                                         //~1114R~

public interface KeyListener //~1113R~
{                                                                  //~1112I~
    void keyPressed(KeyEvent ev);                                  //+1317R~
    void keyReleased(KeyEvent ev);                                 //+1317R~
    void keyTyped(KeyEvent ev);                                    //~1113R~
}                                                                  //~1112I~