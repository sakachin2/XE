package com.Ajagoc.awt;                                                //~1108R~//~1109R~

public class BorderLayout                                          //+1124R~
{                                                                  //~1111I~
    public BorderLayout()                                                 //~1111I~//+1124R~
    {                                                              //~1111I~
    }                                                              //~1111I~
    public void setAlignment(int P1)                               //~1124I~
    {                                                              //~1124I~
    }                                                              //~1124I~
}
