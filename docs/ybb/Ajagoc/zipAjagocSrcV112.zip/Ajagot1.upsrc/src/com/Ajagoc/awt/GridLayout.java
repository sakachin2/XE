package com.Ajagoc.awt;                                                //~1108R~//~1109R~

public class GridLayout                                            //~1124R~
{                                                                  //~1111I~
    public GridLayout()                                                 //~1111I~//~1124R~
    {                                                              //~1111I~
    }                                                              //~1111I~
    public GridLayout(int p1,int p2)                               //~1124I~
    {                                                              //~1124I~
    }                                                              //~1124I~
    public void setAlignment(int P1)                               //~1124I~
    {                                                              //~1124I~
    }                                                              //~1124I~
}
