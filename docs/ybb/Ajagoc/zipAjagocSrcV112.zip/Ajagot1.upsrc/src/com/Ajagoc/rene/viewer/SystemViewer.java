//*CID://+dateR~: update#=  45;                                    //~1107R~
//**********************************************************************//~1107I~
//*TextArea width Vertical ScrollView                              //~1214R~
//**********************************************************************//~1107I~
package com.Ajagoc.rene.viewer;                                         //~1107R~  //~1108R~//~1109R~//~1214R~


public class SystemViewer extends Viewer                           //+1214I~
{

	public SystemViewer()
	{
		super();
	}                                                              //~1111I~//~1112I~
}//class                                                              //~1111I~//~1112I~
