package com.Ajagoc.awt;

public interface MouseListener                                     //+1213I~
{                                                                  //+1213I~
    public void mouseClicked(MouseEvent e);                        //+1213I~
    public void mousePressed(MouseEvent e);                        //+1213I~
    public void mouseReleased(MouseEvent e);                       //+1213I~
    public void mouseEntered(MouseEvent e);                        //+1213I~
    public void mouseExited(MouseEvent e);                         //+1213I~
}                                                                  //+1213I~
