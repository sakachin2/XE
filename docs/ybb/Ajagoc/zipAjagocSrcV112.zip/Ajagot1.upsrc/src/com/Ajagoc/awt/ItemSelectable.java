package com.Ajagoc.awt;

public interface ItemSelectable {                                  //+1214I~
                                                                   //+1214I~
    public Object[] getSelectedObjects();                          //+1214I~
    public void addItemListener(ItemListener l);                   //+1214I~
    public void removeItemListener(ItemListener l);                //+1214I~
}                                                                  //+1214I~
