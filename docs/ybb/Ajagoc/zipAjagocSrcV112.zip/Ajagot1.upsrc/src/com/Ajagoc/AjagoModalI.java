//*CID://+dateR~: update#=  88;                                    //~1107R~
//**********************************************************************//~1107I~
package com.Ajagoc;                                         //~1107R~  //~1108R~//~1109R~

//**********************************************************************//~1107I~
public interface AjagoModalI                                       //~1330R~
{                                                                  //~0914I~
	public void onDismissModalDialog(boolean PmodalOnSubthred);                        //~1214R~//+1407R~
}                                                                  //~1330R~
