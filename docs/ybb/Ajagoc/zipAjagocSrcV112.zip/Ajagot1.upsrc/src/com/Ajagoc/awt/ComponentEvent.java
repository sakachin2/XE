package com.Ajagoc.awt;                                                //~1108R~//~1109R~

public class ComponentEvent                                        //~1212R~
{   
	public ComponentEvent()                                        //~1212R~
	{
	}
}//class                                                           //~1212R~
