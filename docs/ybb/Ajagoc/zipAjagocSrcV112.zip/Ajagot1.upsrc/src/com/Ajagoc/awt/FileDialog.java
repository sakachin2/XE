//*CID://+v105R~:                             update#=    9;       //~v105I~
//*************************************************************************//~v105I~
//1054:121114 filedialog could not traverse dir                    //~v105I~
//1053:121113 exception(wrong thread) when filelist up/down for sgf file read//~v105I~
//*************************************************************************//~v105I~
package com.Ajagoc.awt;                                                //~1108R~//~1109R~

import java.io.File;
import java.io.FilenameFilter;

import com.Ajagoc.AjagoAlert;
import com.Ajagoc.AjagoProp;
import com.Ajagoc.AjagoView;
import com.Ajagoc.R;

import jagoclient.Dump;
import jagoclient.Global;
import jagoclient.gui.ButtonAction;
import jagoclient.gui.CloseDialog;
import jagoclient.gui.CloseFrame;

                                                                   //~1319R~
public class FileDialog extends CloseDialog                        //~1403R~
{                                                                  //~1111I~
    private int mode;                                              //~1319I~
    public final static int LOAD   =0;	//read  permisson          //~1319I~
    public final static int SAVE   =1;	//write permisson          //~1319I~
                                                                   //~1402I~
    private String title;                                          //~1319I~
//    private CloseFrame parentFrame;                                          //~1319I~//~v105R~
    private String dirname="";                                     //~1324R~
    private String filterString=null;                              //~1324R~
    private FilenameFilter filterCB=null;                          //~1407R~
    public  String[] namelist;                                      //~1319I~//~1402R~
	private File[] filelist;                                       //~1319I~
	private int[]  name2file;                                      //~1330I~
	private File   selectedFile;                                   //~1403R~
	private static String selectedFilename=null;                   //~1319I~//~1330R~
	private static String selectedDirname=null;                    //~1330I~
                          //~1402I~
    private String savefilename="";                                //~1402I~
    private boolean afterDismiss;                                   //~1330I~
    private TextField input;
    private Label labelCD;
	private Lister lister;                                         //~1403I~
    private ButtonAction buttonOpen,buttonSave,buttonDel,buttonCan; //~1403I~
    private String updownpath;                                            //~1403I~
    private Color bgcolor=Global.gray;                             //~1403I~
    private boolean swSaveBitmap;                                  //~1404I~
    private boolean swSaveGame=false;                              //~1407I~
    private boolean swSaveTxt=false;                               //~1418I~
//***********                                                      //~1319I~
    public FileDialog(CloseFrame  Pframe,String Ptitle,int Pmode)  //~1324I~
    { 
	 	super(Pframe,"FileDialog",true/*modal*/);                  //~1403I~
	 	afterDismiss=isAfterDismiss();
	 	if (Dump.Y) Dump.println("FileDialog:afterdismiss="+afterDismiss);//~1506R~
//        parentFrame=Pframe;                                        //~1403M~//~v105R~
		title=Ptitle;                                              //~1403M~
        mode=Pmode;                                                //~1403M~
        if (Pframe instanceof FilenameFilter)                      //~1407I~
	        filterCB=(FilenameFilter)Pframe;                       //~1407R~
        else                                                       //~1407I~
        	filterCB=null;                                         //~1407I~
		swSaveBitmap=(Global.resourceString("Save_Bitmap").equals(Ptitle)); // save to bitmap;//~1404I~
                                                                   //~1403I~
	 	if (afterDismiss)                                          //~1403M~
	 		return;                                                //~1403M~
                                                                   //~1403I~
	 	if (mode==LOAD)                                            //~1403I~
			labelCD=new Label("CurrDir");                          //~1403I~
        else                                                       //~1403I~
			labelCD=new Label("Name");                             //~1403R~
		input=new TextField("New");                            //~1403I~
        if (mode==LOAD)                                            //~1403I~
        	input.setEditable(false);                         //~1403I~
        else                                                       //~1403R~
        	input.setEditable(true);                               //~1403R~
		lister=new Lister();                                       //~1403I~
    	buttonOpen=new ButtonAction(this,Global.resourceString("Open")); //~1113R~//~1403I~
    	buttonSave=new ButtonAction(this,Global.resourceString("Save"));//~1403I~
    	buttonDel=new ButtonAction(this,Global.resourceString("Delete"));//~1403I~
    	buttonCan=new ButtonAction(this,Global.resourceString("Cancel"));//~1403I~
        if (mode==LOAD)                                            //~v105I~
        	((Component)buttonSave).setEnabled((Button)buttonSave,false);         //~v105I~
        if (Dump.Y) Dump.println("FileDialog:title="+Ptitle+",selectedFilename="+selectedFilename);//~1324I~//~1506R~
    }                                                              //~1214I~
//***********                                                      //~1319I~
	public FileDialog(CloseFrame Pframe,String Ptitle,int Pmode,String Pdir)//~1319R~
    {                                                              //~1319I~
		this(Pframe,Ptitle,Pmode);                                //~1319R~
		setDirectory(Pdir);                                        //~1319I~
    }                                                              //~1319I~
//***********                                                      //~1319I~
	public void setDirectory(String Pdir)                          //~1319I~
    {                                                              //~1319I~
        if (Dump.Y) Dump.println("FileDialog setDirectory :"+Pdir);//~1506R~
        dirname="";	//use Preference                               //~1402I~
    }                                                              //~1319I~
//***********                                                      //~1319I~
	public String getDirectory()                                   //~1319I~
    {                                                              //~1319I~
    	String path;
		if (afterDismiss)                                          //~1403R~
        	path=selectedDirname;                                  //~1330I~
        else                                                       //~1330I~
        	path="";                                               //~1403R~
        if (Dump.Y) Dump.println("FileDialog getDirectory :"+path+",afterdismiss="+afterDismiss);//~1506R~
    	return path+"/";                                        //~1319I~//~1326R~//~1330R~
    }                                                              //~1319I~
//***********                                                      //~1319I~
	public void setFile(String Pfile)                              //~1319I~
    {                                                              //~1319I~
        if (Dump.Y) Dump.println("FileDialog:setFile="+Pfile);     //~1506R~
        filterString=Pfile;                                        //~1402I~
        savefilename="";                                           //~1403I~
		swSaveGame=(Pfile.equals("*.sto")); // save to bitmap;     //~1407R~
		swSaveTxt=(Pfile.equals("*.txt")); // save to bitmap;      //~1418I~
        if (mode==SAVE)                                            //~1402M~
        {                                                          //~1402I~
            savefilename=Pfile;                                    //~1404R~
            filterString="";                                       //~1404R~
        }                                                          //~1402I~
    }                                                              //~1319I~
//***********                                                      //~1319I~
	public String getFile()                                        //~1319I~
    {                                                              //~1319I~
        if (Dump.Y) Dump.println("FileDialog getFile:"+selectedFilename+",afterdismiss="+afterDismiss);//~1506R~
        if (!afterDismiss)                                         //~1402I~
        	return null;                                           //~1402I~
    	return selectedFilename;                                   //~1319I~
    }                                                              //~1319I~
//***********                                                      //~1319I~
	public void setFilenameFilter(FilenameFilter Pfilter)         //~1319I~
    {                                                              //~1319I~
    	filterCB=Pfilter;                                          //~1407R~
    }                                                              //~1319I~
//***********                                                      //~1319I~
	public void setLocation(int Px,int Py)                         //~1319I~
    {                                                              //~1319I~
    }                                                              //~1319I~
//***********                                                      //~1319I~
	public void show()                                             //~1319I~
    {                                                              //~1319I~
    	if (afterDismiss)                                          //~1324I~
        	return;     //avoid redo dialog doAction schedule      //~1403R~
    	createList(dirname);                                      //~1403I~
    	if (namelist==null)                                        //~1323I~
        	return;                                                //~1323I~
        setTitleFilename(dirname);                                 //~1403M~
    	setList();                                                 //~1403I~
    	super.show();                                              //~1403R~
        afterDismiss=isAfterDismiss();	//true if subthread modal  //~1407I~
        if (Dump.Y) Dump.println("FileDialog:after show,afterDismiss="+afterDismiss);//~1506R~
    }                                                              //~1319I~
//***********                                                      //~v105I~
	public void redraw()                                           //~v105I~
    {                                                              //~v105I~
    	shown=false;	//Dilaog                                       //~v105I~
    	super.show();                                              //~v105I~
        if (Dump.Y) Dump.println("FileDialog:redraw");              //~v105I~
    }                                                              //~v105I~
    //**********************************                           //~1403I~
    //* init ListView                                              //~1403I~
    //**********************************                           //~1403I~
    private void setList()                                         //~1403R~
    {                                                              //~1403I~
        int sz=namelist.length;                                    //~1411R~
        for (int ii=0;ii<sz;ii++)                                      //~1411I~
        {                                                          //~1403I~
        	lister.appendLine(namelist[ii]);                       //~1403R~
        }                                                          //~1403I~
        if (sz>0)                                                  //~1411I~
        {                                                          //~1411I~
	        int pos=(sz==1?0:1);                                   //~1411I~
			lister.setSelection(pos);//current dir for save,top file for load//~1411R~
        }                                                          //~1411I~
        lister.setBackground(bgcolor);	                           //~1403I~
        selectedDirname=dirname;                                   //~1403I~
    }                                                              //~1403I~
    //**********************************                           //~1319I~
    //* file submenu selected;create submenu listview              //~1319I~
    //**********************************                           //~1319I~
    private void createList(String Pdirname)                       //~1402R~
    {                                                              //~1319I~
    	File fileCurDir;                                           //~1403R~
    //************************                                     //~1319I~
    	String path=Pdirname;                                      //~1402R~
        if (Dump.Y) Dump.println("createList path="+path);         //~1506R~
        if (path==null                                             //~1323I~
        ||  path.equals("")                                        //~1323I~
        )                                                          //~1323I~
        {                                                          //~1323I~
        	path=AjagoProp.getPreference(AjagoProp.GAMEFILE,null/*default*/);//~1402I~
            if (path==null)                                        //~1402I~
            	path=AjagoProp.getSDPath("");                          //~1323I~//~1402R~
            if (path==null)                                        //~1323I~
            {                                                      //~1323I~
            	AjagoView.showToast(R.string.NoSDCard);            //~1403I~
                namelist=null;                                     //~1323I~
                return;                                            //~1323I~
            }                                                      //~1323I~
        }                                                          //~1323I~
        dirname=path;                                              //~1402I~
        try{                                                       //~1319I~
        	if (Dump.Y) Dump.println("FileDialog path="+path);     //~1506R~
            fileCurDir=new File(path);                             //~1403R~
            filelist=fileCurDir.listFiles();   //file and dir      //~1403R~
            if(filelist==null)                                     //~1319I~
            {                                                      //~1319I~
				AjagoAlert.simpleAlertDialog(/*AjagoAlertI*/null,path,"No Entry",AjagoAlert.BUTTON_CLOSE);//~1319I~
            }                                                      //~1319I~
            else                                                   //~1319I~
            {                                                      //~1319I~
                int count = 1;                                     //~1403M~
                int filelistctr=0;                                 //~1403M~
                String name;                                       //~1403M~
                                                                   //~1403I~
                if (mode==SAVE)                                    //~1403I~
                	count++;                                       //~1403I~
            	name2file=new int[filelist.length+count];          //~1403R~
                                                                   //~1403I~
                for (File file : filelist)                         //~1325I~
                {                                                  //~1325I~
                    name=file.getName();                           //~1325I~
		        	if (Dump.Y) Dump.println("FileDialog file="+name);//~1506R~
                    if(!file.isDirectory())                        //~1404R~
                    {                                              //~1404I~
                    	if (swSaveBitmap)                          //~1404I~
                        {                                          //~1404I~
							if (!bitmapAccept(fileCurDir,name))	//GoFrame accept() acept sgf or xml only//~1404I~
		                        continue;                          //~1404I~
                        }                                          //~1404I~
                   	 	else                                       //~1404R~
                    	if (swSaveGame)                            //~1407I~
                        {                                          //~1407I~
							if (!saveGameAccept(fileCurDir,name))	//PartnerFrame//~1407I~
		                        continue;                          //~1407I~
                        }                                          //~1407I~
                   	 	else                                       //~1407I~
                    	if (swSaveTxt)                             //~1418I~
                        {                                          //~1418I~
							if (!saveTxtAccept(fileCurDir,name))	//PartnerFrame//~1418I~
		                        continue;                          //~1418I~
                        }                                          //~1418I~
                   	 	else                                       //~1418I~
                        {                                          //~1404I~
                        	if (filterCB!=null && !filterCB.accept(fileCurDir,name))//~1407I~
		                        continue;                          //~1404R~
                        }                                          //~1404I~
                    }                                              //~1404I~
                    count++;                                       //~1325I~
                }                                                  //~1325I~
                namelist=new String[count];            //~1323R~   //~1325R~
                                    //~1319I~
                if (mode==LOAD)                                    //~1403I~
                {                                                  //~1403I~
                	namelist[0]="<--Up";                           //~1403R~
	                count = 1;                                     //~1403I~
                }                                                  //~1403I~
                else                                               //~1403I~
                {                                                  //~1403I~
                	                                               //~1403I~
                	namelist[0]="<--Up";                           //~1403I~
                	namelist[1]="./ ("+dirname+")";                //~1403I~
	                count = 2;                                     //~1403I~
                }                                                  //~1403I~
                for (File file : filelist)                         //~1319I~
                {                                                  //~1319I~
                    name=file.getName();                           //~1319I~
                    name2file[count]=filelistctr++;                //~1330I~
		        	if (Dump.Y) Dump.println("FileDialog file="+name);//~1506R~
                    if(file.isDirectory())                         //~1319I~
                    {                                              //~1319I~
                    	name+="/";	//linux File.pathSeparator;                  //~1319I~//~1325R~
                    }                                              //~1319I~
                    else                                           //~1325I~
                    {                                              //~1402I~
                    	if (swSaveBitmap)                          //~1404I~
                        {                                          //~1404I~
							if (!bitmapAccept(fileCurDir,name))	//GoFrame accept() acept sgf or xml only//~1404I~
		                        continue;                          //~1404I~
                        }                                          //~1404I~
                   	 	else                                       //~1404I~
                    	if (swSaveGame)                            //~1407I~
                        {                                          //~1407I~
							if (!saveGameAccept(fileCurDir,name))	//PartnerFrame//~1407I~
		                        continue;                          //~1407I~
                        }                                          //~1407I~
                   	 	else                                       //~1407I~
                    	if (swSaveTxt)                             //~1418I~
                        {                                          //~1418I~
							if (!saveTxtAccept(fileCurDir,name))	//PartnerFrame//~1418I~
		                        continue;                          //~1418I~
                        }                                          //~1418I~
                   	 	else                                       //~1418I~
                        {                                          //~1404I~
                    		if (filterCB!=null && !filterCB.accept(fileCurDir,name))//~1407R~
                        		continue;                          //~1404R~
                        }                                          //~1404I~
                        int pos=name.lastIndexOf('.');             //~1402I~
                        if (pos>0)                                 //~1402I~
                        	name=name.substring(0,pos);            //~1402I~
                    }                                              //~1402I~
                    namelist[count++]=name;                        //~1319I~
                }                                                  //~1319I~
            }                                                      //~1319I~
        }                                                          //~1319I~
        catch(SecurityException e)                                 //~1319I~
        {                                                          //~1319I~
            AjagoView.showToast(R.string.FailedListDirBySecurity);   //~1403I~
            namelist=null;                                         //~v105I~
        }                                                          //~1319I~
		catch(Exception e)                                         //~1319I~
		{                                                          //~1319I~
            AjagoView.showToast(R.string.FailedListDir);           //~1403I~
            namelist=null;                                         //~v105I~
        }                                                          //~1319I~
    }//createList                                                  //~1402R~
    //**********************************                           //~1402I~
    private void updateList(String Pdirname)                    //~1402I~
    {                                                              //~1402I~
    	if (Dump.Y) Dump.println("FileDialog:updateAdapter dir="+Pdirname);//~1506R~
    	createList(Pdirname);                                      //~1402I~
        if (namelist==null)                                        //~1403I~
        	return;                                                //~1403I~
	    setTitleFilename(Pdirname);	//lis will be cleared at next append//~1403I~
        lister.clearList();                                        //~1403I~
    	setList();                                                 //~1403I~
        AjagoProp.putPreference(AjagoProp.GAMEFILE,Pdirname);      //~1403I~
    }//FileList                                                    //~1402R~
	//***************************************                      //~1402I~
    private void setTitleFilename(String Pdirname)                         //~1402I~
    {                                                              //~1402I~
        String dlgtitle;                                           //~1402I~
    //************************                                     //~1402I~
        dlgtitle=title;                                            //~1402I~
        if (mode==LOAD)                                            //~1402I~
        {                                                          //~1402I~
			if (filterString!=null && !filterString.equals(""))               //~1402I~
                dlgtitle+=" ("+filterString+")";                   //~1402I~
			input.setText(dirname);
        }
        else 
        	input.setText(savefilename);//~1402I~
    	setTitle(dlgtitle);  //of Dialog                           //+1403R~                           //~1403I~
    }                                                              //~1402I~
	//***************************************                      //~1402R~
	public void doAction (String o)                                //~1403I~
	{                                                              //~1403I~
    	boolean swshow=false,rc;                                   //~v105I~
    //***************************                                  //~v105I~
      try                                                          //~v105I~
      {                                                            //~v105I~
    	selectedFilename=null;                                     //~1403R~
    	selectedDirname="";                                        //~1403I~
		if (o.equals(Global.resourceString("Open")))               //~1403R~
		{                                                          //~1403I~
    		if (openSelected())      //file is selected            //~1403R~
	        	dispose();	         //dismiss                     //~1403I~
            else                                                   //~v105I~
            	swshow=true;                                       //~v105I~
            if (Dump.Y) Dump.println("FileDialog Open dir="+dirname+",file="+selectedFilename);//~1506R~
		}                                                          //~1403I~
		else if (o.equals(Global.resourceString("Save")))          //~1403I~
		{                                                          //~1403I~
        	if (mode==LOAD)                                        //~1403I~
 //         	return;	//ignore click                             //~1403I~//~v105R~
            	swshow=true;	//ignore click                     //~v105I~
            else                                                   //~v105I~
        	if (saveSelected()) //valid directory                  //~1403I~
	        	dispose();	         //dismiss                     //~1403I~
            else                                                   //~v105I~
            	swshow=true;	//ignore click                     //~v105I~
            if (Dump.Y) Dump.println("FileDialog save dir="+dirname+",file="+selectedFilename);//~1506R~
		}                                                          //~1403I~
		else if (o.equals(Global.resourceString("Delete")))        //~1403I~
		{                                                          //~1403I~
    		deleteSelected();                                       //~1403I~
            if (Dump.Y) Dump.println("FileDialog Delete dir="+dirname+",file="+selectedFilename);//~1506R~
            swshow=true;                                           //~v105I~
		}                                                          //~1403I~
		else if (o.equals(Global.resourceString("Cancel")))        //~1403I~
		{                                                          //~1403I~
            if (Dump.Y) Dump.println("FileDialog Cancel");         //~1506R~
	        dispose();	         //dismiss                         //~1403I~
		}                                                          //~1403I~
		else super.doAction(o);	//Cancel                           //~1403I~
      }                                                            //~v105I~
      catch (Exception e)                                          //~v105I~
      {                                                            //~v105I~
      	Dump.println(e,"FileDialog:doAction Exception");           //~v105I~
       	AjagoView.showToast(R.string.Exception);                   //~v105I~
	    dispose();	         //dismiss                             //~v105I~
        swshow=false;                                              //~v105I~
      }                                                            //~v105I~
      if (swshow)                                                  //~v105I~
      	redraw();                                                  //~v105I~
    }                                                              //~1403R~
    //**********************************************************************//~1403I~
    //* open                                                       //~1403I~
    //**********************************************************************//~1403I~
    private boolean openSelected()                                 //~1403I~
    {                                                              //~1403I~
    	int selectedstatus;                                        //~1403I~
        boolean rc=false;                                          //~1403I~
    //***                                                          //~1403I~
    	selectedstatus=chkSelectedFilename();                      //~1403I~
        switch(selectedstatus)                                     //~1403I~
        {                                                          //~1403I~
        case -1:	//no selection                                 //~1403R~
            break;                                                 //~1403I~
        case 0:	//file selected	                                   //~1403I~
        	if (mode==LOAD)                                        //~1403I~
            {                                                      //~1403I~
		        selectedDirname=dirname;                           //~1403I~
            	rc=true;	//dismiss                              //~1403R~
            }                                                      //~1403I~
            else                                                   //~1403I~
            	AjagoView.showToast(R.string.NotDir);              //~1403I~
            break;                                                 //~1403I~
        default:	//dir or up                                    //~1403R~
        	if (mode==SAVE)                                        //~1404I~
        		savefilename=input.getText(true);  //may updated on input field//~1411R~
        	updateList(updownpath);                                //~1403I~
        }                                                          //~1403I~
        return rc;                                                 //~1403I~
    }                                                              //~1403I~
    //**********************************************************************//~1402I~
    //* save                                                       //~1403R~
    //**********************************************************************//~1402I~
    private boolean saveSelected()                                 //~1403R~
    {                                                              //~1402I~
    	int selectedstatus;                                        //~1403I~
        String savepath=null;                                      //~1403I~
        boolean mkdir=false;                                       //~1403I~
    //***                                                          //~1403I~
    	selectedstatus=chkSelectedFilename();                      //~1403I~
        switch(selectedstatus)                                     //~1403I~
        {                                                          //~1403I~
        case -1:                                                   //~1403I~
            savepath=dirname;                                      //~1403I~
            break;                                                 //~1403I~
        case 0:	//file selected                                    //~1403I~
            AjagoView.showToast(R.string.NotDir);                  //~1403I~
            return false;                                          //~1403I~                                               //~1403I~
        default:                                                   //~1403I~
        //case 1:	//dir selected                                 //~1403R~
        //case 2:	//up slected                                   //~1403R~
        //case 3:	//current dir                                  //~1403I~
            savepath=updownpath;                                   //~1403I~
        }                                                          //~1403I~
	    if (Dump.Y) Dump.println("FileDialog save savepath="+savepath);//~1506R~
        String newpath=input.getText(true).toString();             //~1411R~
        if (newpath==null || newpath.equals(""))                   //~1403R~
        	return false;                                          //~1403I~
        int pos=newpath.lastIndexOf('/');                          //~1403I~
        if (pos==0)                                                //~1403I~
        {                                                          //~1403I~
            savepath="/";                                          //~1403I~
            selectedFilename=newpath.substring(1);                 //~1403I~
        }                                                          //~1403I~
        else                                                       //~1403I~
        if (pos>0)                                                 //~1403I~
        {                                                          //~1403I~
            savepath+="/"+newpath.substring(0,pos);                //~1403I~
            selectedFilename=newpath.substring(pos+1);             //~1403I~
            if (selectedFilename.length()==0)                            //~1403I~
                return false;                                      //~1403I~
            mkdir=true;                                            //~1403I~
        }                                                          //~1403I~
        else                                                       //~1403I~
            selectedFilename=newpath;                              //~1403I~
        if (Dump.Y) Dump.println("FileDialog save newpath="+savepath+"file="+selectedFilename);//~1506R~
        if (mkdir)                                                 //~1403I~
        {                                                          //~1403R~
            if (!AjagoProp.makePath(savepath))                     //~1403R~
            {                                                      //~1403R~
                AjagoView.showToast(R.string.FailedMkdir);         //~1403R~
                return false;                                      //~1403R~
            }                                                      //~1403R~
        }                                                          //~1403R~
        selectedDirname=savepath;                                  //~1403R~
        if (Dump.Y) Dump.println("FileDialog save path="+selectedDirname+",file="+selectedFilename);//~1506R~
        AjagoView.showToast(R.string.Saved,selectedDirname+"/"+selectedFilename);//+v105I~
        return true;                                               //~1402I~
    }                                                              //~1402I~
    //**********************************************************************//~1402I~
    //* delete                                                     //~1403R~
    //**********************************************************************//~1402I~
    private boolean deleteSelected()                                  //~1402I~
    {                                                              //~1402I~
    	int selectedstatus=chkSelectedFilename();                      //~1403I~
        boolean rc;
    	switch(selectedstatus)                                     //~1403I~
        {                                                          //~1403I~
        case 0:	//file selected                                    //~1403I~
        	break;                                                 //~1403I~
        case 1:	//dir selected,delete if empty                     //~1403I~
        	File[] fl=selectedFile.listFiles();                         //~1403I~
            if (fl!=null && fl.length!=0)                          //~1403I~
            {                                                      //~1403I~
            	AjagoView.showToast(R.string.NotEmptyDir);         //~1403I~
                return false;                                      //~1403I~
            }                                                      //~1403I~
            break;                                                 //~1403I~
        default:                                                   //~1403I~
            return false;                                          //~1403I~
        }                                                          //~1403I~
    	try                                                        //~1402I~
        {                                                          //~1402I~
        	                                                       //~1403I~
        	selectedFile.delete();                                 //~1403R~
	        if (Dump.Y) Dump.println("FileDialog deleted file="+selectedFile.getName());//~1506R~
		    updateList(dirname);
		    rc=true;//~1402I~
        }                                                          //~1402I~
        catch (Exception e)                                        //~1402I~
        {                                                          //~1402I~
        	Dump.println(e,"FileDialog:deleteSelected Exception"); //~1402I~
    		if (selectedstatus==0)                                 //~1403I~
            	AjagoView.showToast(R.string.FailedDelete);        //~1403I~
            else                                                   //~1403I~
            	AjagoView.showToast(R.string.FailedRemoveDir);     //~1403I~
        	rc=false;
        }
        return rc;//~1402I~
    }                                                              //~1402I~
    //**********************************************************************//~1319I~
    //*chk list selection                                          //~1403I~
    //*rc:-1:err,0 file selected,1:dir selected,2:"up" selected 3:save to currentdir//~1403R~
    //**********************************************************************//~1403I~
    private int chkSelectedFilename()                              //~1403R~
    {                                                              //~1319I~
        int pos,rc=0;                                              //~1403I~
    //************                                                 //~1403R~
    	selectedFilename=null;                                     //~1403I~
        pos=lister.getSelectedPos();                               //~1403I~
        if (Dump.Y) Dump.println("FileDialog selectedPos="+pos);   //~1506R~
        if (pos<0)                                                 //~1403I~
        	return -1;                                             //~1403I~
        if (pos==0)                                                //~1403R~
        {                                                          //~1403R~
            updownpath=(new File(dirname)).getParent();            //~1403R~
            rc=2;                                                  //~1403I~
        }                                                          //~1403R~
        else                                                       //~1403I~
        if (mode==SAVE && pos==1)	//currentdir                   //~1403I~
        {                                                          //~1403I~
            updownpath=dirname;                                    //~1403I~
        	rc=3;                                                   //~1403I~
        }                                                          //~1403I~
        else                                                       //~1403R~
        {                                                          //~1403R~
            int filelistpos=name2file[pos];                        //~1403R~
            selectedFile=filelist[filelistpos];                             //~1319I~//~1403R~
            if(selectedFile.isDirectory())                                 //~1403R~
            {                                                      //~1403R~
                updownpath=selectedFile.getAbsolutePath();                   //~1319I~//~1324R~//~1403R~
                rc=1;                                              //~1403I~
            }                                                      //~1403R~
            else                                                   //~1403R~
            {                                                      //~1403R~
            	selectedFilename=selectedFile.getName();                   //~1403R~
            }                                                      //~1403R~
        }
        
        if (Dump.Y) Dump.println("FileDialog chkSelectedfile rc="+rc+",name="+selectedFilename);//~1319I~//~1506R~
        return rc;
    }
	public boolean bitmapAccept(File dir, String name)             //~1404I~
	{                                                              //~1404I~
		if (name.endsWith("."+Global.getParameter("extension","bmp"))) return true;//~1404I~
		else return false;                                         //~1404I~
	}                                                              //~1404I~
	public boolean saveGameAccept(File dir,String name)            //~1407I~
	{                                                              //~1407I~
		if (name.endsWith("."+Global.getParameter("extension","sto"))) return true;//~1407I~
		else return false;                                         //~1407I~
	}                                                              //~1407I~
	public boolean saveTxtAccept(File dir,String name)             //~1418I~
	{                                                              //~1418I~
		if (name.endsWith("."+Global.getParameter("extension","txt"))) return true;//~1418I~
		else return false;                                         //~1418I~
	}                                                              //~1418I~
}//class                                                           //~1318R~
