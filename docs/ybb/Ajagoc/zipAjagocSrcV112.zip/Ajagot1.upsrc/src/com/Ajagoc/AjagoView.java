//*CID://+1B18R~: update#= 162;                                    //~1B18R~
//**********************************************************************//~1107I~
//1B18 130505 xoom(Android3.1) listview touch is ignored when back from OpenPartnerFrame//~1B18I~
//1B0g 130430 catch OutOfMemoryError                               //~1B0gI~
//1B0c 130429 Encoding support for partner connection              //~1B0cI~
//1104:130126 fix orientation                                      //~v110I~
//1065:121124 PartnerConnection;FinishGame-->EndGame:send EndGEm req and if responsed, allog RemoveGroup.//~v106I~
//            Igs and GMP is FinishGame-->Remove groupe/prisoner   //~v106I~
//            change Menu Item Text for partner connection(send End game request)//~v106I~
//            Isue reply msg and notify "Remove Prisoner" avalable //~v106I~
//v101:120514 (Axe)android3(honeycomb) tablet has System bar at bottom that hide xe button line with 48pix height//~v101I~
//**********************************************************************//~v101I~
//*main view                                                       //~1107I~
//**********************************************************************//~1107I~
package com.Ajagoc;                                         //~1107R~  //~1108R~//~1109R~

import jagoclient.Dump;

import com.Ajagoc.awt.Frame;
import com.Ajagoc.awt.Window;


import android.content.Context;                                    //~0913I~
import android.content.pm.ActivityInfo;                            //~v110I~
import android.content.res.Configuration;                          //~v110I~
import android.graphics.Point;
import android.graphics.Rect;

import android.view.Display;
import android.view.Surface;                                       //~v110I~
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TabHost;
import android.widget.TabHost.TabSpec;
import android.widget.Toast;

import android.widget.TextView;
import android.view.WindowManager;


public class AjagoView extends View                                  //~0914R~//~dataR~
	implements View.OnClickListener, AjagoUiThreadI
{                                                                  //~0914I~
	private static final String[] Stab_tags={"MainFrame_tag_Servers","MainFrame_tag_Partners"};//~1122I~
    private Button[] tabbtns=new Button[2];                          //~1122I~
    private TabHost tabhost;                                       //~1122I~
    static private View contentView;                               //~1425R~
    private int tabctr;                                            //~1425R~
    private static boolean idLong;                                               //~1514I~
	public AjagoView()                                //~0914R~//~dataR~//~1107R~//~1111R~
    {                                                              //~0914I~
    	super(AG.context);                                         //~1111I~
        if (Dump.Y) Dump.println("AjagoView Constructor");         //~1506R~
    }                                                              //~0914I~
    //******************************************                   //~v110I~
    //*from Canvas when landscape                                  //~v110I~
    //******************************************                   //~v110I~
	public void startMain()                                       //~1120I~//~1122I~
    {                                                              //~1120I~//~1122M~
        try                                                        //~1109I~//~1120M~//~1122M~
        {                                                          //~1109I~//~1120M~//~1122M~
			fixOrientation(true);                                  //~v110I~
	    	getScreenSize();                                       //~1122I~
//	    	initMainFrame();                                       //~1122I~
	        AG.ajagoMain.startMain();                              //~1122I~
        }                                                          //~1109I~//~1120M~//~1122M~
        catch(Exception e)                                         //~1109I~//~1120M~//~1122M~
        {                                                          //~1109I~//~1120M~//~1122M~
    		Dump.println(e,"AjagoView startMain exception");//~1109I~//~1120M~//~1122M~//~1329R~
        }                                                          //~1109I~//~1120M~//~1122M~
    }                                                              //~1120I~//~1122M~
//*************************                                        //~1122M~
	public void getScreenSize()                                    //~1122M~
    {                                                              //~1122M~
		Display display=((WindowManager)(AG.context.getSystemService(Context.WINDOW_SERVICE))).getDefaultDisplay();//~1122M~
        AG.scrWidth=display.getWidth();                            //~1122M~
        AG.scrHeight=display.getHeight();                          //~1122M~
        if (Dump.Y) Dump.println("AjagoView: getScreenSize w="+display.getWidth()+",h="+display.getHeight());//~1506R~
        AG.dip2pix=AG.resource.getDisplayMetrics().density;        //~1428I~
        if (Dump.Y) Dump.println("AjagoView: dp2pix="+AG.dip2pix); //~1506R~
        AG.portrait=(AG.scrWidth<AG.scrHeight);                    //~1223R~
        getTitleBarHeight();                                       //~1413M~
    }                                                              //~1122M~
    public static void getTitleBarHeight()                         //~1413R~
    {                                                              //~1413M~
        Rect rect=new Rect();                                      //~1413M~
        android.view.Window w=AG.activity.getWindow();                                 //~1413M~
        View v=w.getDecorView();                                   //~1413M~
        v.getWindowVisibleDisplayFrame(rect);                      //~1413M~
        if (Dump.Y) Dump.println("Ajagoc DecorView rect="+rect.toString());//~1506R~
        v=w.findViewById(android.view.Window.ID_ANDROID_CONTENT);               //~1413M~
        AG.titleBarTop=rect.top;                                   //~1413M~
        AG.titleBarBottom=v.getTop();                              //~1413M~
        if (Dump.Y) Dump.println("Ajagoc TitleBar top="+AG.titleBarTop+",bottom="+AG.titleBarBottom);//~1506R~
    }                                                              //~1413M~
    public static Point getTitleBarPosition()                      //~1413I~
    {                                                              //~1413I~
    	if (AG.titleBarBottom==0)                                  //~1413I~
        	getTitleBarHeight();                                   //~1413I~
        return new Point(AG.titleBarTop,AG.titleBarBottom);        //~1413I~
    }                                                              //~1413I~
    public static int getFramePosition()                         //~1413I~
    {                                                              //~1413I~
    	if (AG.titleBarBottom==0)                                  //~1413I~
        	getTitleBarHeight();                                   //~1413I~
        return AG.titleBarBottom;                                  //~1413I~
    }                                                              //~1413I~
    public static int getMargin()                                  //~v101I~
    {                                                              //~v101I~
    	int top=getFramePosition();                                //~v101I~
        return top+AG.bottomSpaceHeight;                           //~v101I~
    }                                                              //~v101I~
//******************                                               //~1326I~
    public void setContentView(Frame Pframe)                       //~1326I~
    {                                                              //~1326I~
        AjagoUiThread.runOnUiThreadWait(this,Pframe);              //~1326I~
    }                                                              //~1326I~
    public void runOnUiThread(Object Pparm)                        //~1326I~
    {                                                              //~1326I~
    	if (Pparm instanceof Frame)                                //~1513I~
        {                                                          //~1513I~
            Frame frame=(Frame)Pparm;                              //~1513R~
            View  view=frame.framelayoutview;                      //~1513R~
            if (Dump.Y) Dump.println("setContentView start id="+Integer.toHexString(view.getId()));//~1513R~
            if (Dump.Y) Dump.println("frame name="+frame.framename+"view="+view.toString());//~1513R~
            AG.ajagoc.setContentView(view);                        //~1513R~
            if (frame.currentTitle!=null)                          //~1513R~
                frame.setTitle(frame.currentTitle);     //update also title which may be changed//~1513R~
            else                                                   //~1513R~
                frame.setTitle(frame.framename);                           //~1326I~//~1513R~
            frame.seticonImage(null);//restore icon                //~1513R~
            contentView=view;    //save current for layouting      //~1513R~
            AG.setCurrentFrame(frame);                             //~1513R~
            if (frame==AG.mainframe)                               //~1B18R~
            	if (tabhost!=null)                                 //+1B18I~
					tabhost.clearFocus();                          //+1B18R~
            if (Dump.Y) Dump.println("setContentView end id="+Integer.toHexString(contentView.getId()));//~1513R~
            return;                                                //~1513I~
        }                                                          //~1513I~
    	if (Pparm instanceof String) 	//toast                    //~1513I~
        {                                                          //~1513I~
        	String msg=(String)Pparm;                              //~1513I~
	    	if (Dump.Y) Dump.println("UIshowToast msg="+msg);       //~1513I~
            if (idLong)                                            //~1514I~
		        Toast.makeText(AG.context,msg,Toast.LENGTH_LONG).show();//~1514I~
            else                                                   //~1514I~
		        Toast.makeText(AG.context,msg,Toast.LENGTH_SHORT).show();//~1514R~
            return;                                                //~1513I~
        }                                                          //~1513I~
    }                                                              //~1326I~

//*************************                                        //~1128I~
	static public View inflateView(int Presid)                     //~1128I~
    {                                                              //~1128I~
		View layoutview=inflateLayout(Presid);                     //~1128I~
        return layoutview;                                         //~1128I~
    }                                                              //~1128I~
//******************                                               //~1124I~//~1216M~
	static private View inflateLayout(int Presid)                   //~1122I~//~1216I~
    {                                                              //~1122I~//~1216M~
    	View layoutView=AG.inflater.inflate(Presid,null);          //~1122I~//~1216M~
    	AG.setCurrentView(Presid,layoutView);                      //~1216I~
        return layoutView;                                         //~1122I~//~1216M~
    }                                                              //~1122I~//~1216M~
//**************************************************************   //~1410I~
//*from Dialog,reuse old layout for redo modalDialog Action        //~1410I~
//**************************************************************   //~1410I~
	static public View inflateLayout(int Presid,View PlayoutView) //~1410I~
    {                                                              //~1410I~
    	AG.setCurrentView(Presid,PlayoutView);                     //~1410I~
        return PlayoutView;                                        //~1410I~
    }                                                              //~1410I~
//******************                                               //~1124I~//~1128M~
	static public View getContentView()                            //~1122I~//~1128M~
    {                                                              //~1122I~//~1128M~
        return contentView;                                        //~1122I~//~1128M~
    }                                                              //~1122I~//~1128M~
//******************                                               //~1122I~
//* MainFrameTab ***                                               //~1122I~
//******************                                               //~1122I~
	public void initMainFrameTab(Frame Pmainframe) //from Applet(Go)//~1125R~
    {                                                              //~1122M~
    //************                                                 //~1122M~
    	if (Dump.Y) Dump.println("AjagoView:initMainFrameTab tabctr="+tabctr);//~1506R~
        if (tabctr==0)                                             //~1125R~
        {                                                          //~1125I~
        	initTab();                                                 //~1122I~//~1125R~
        }                                                          //~1125I~
        initCardPanelLayout(tabctr);                               //~1125R~
        tabctr++;                                                  //~1125I~
    }                                                              //~1122M~
//******************                                               //~1122I~
	public void initTab()                                          //~1122I~
    {                                                              //~1122I~
        TabSpec tab;                                               //~1122I~
        Button btn;                                                //~1122I~
    //************                                                 //~1122I~
        tabhost=(TabHost)(contentView.findViewById(android.R.id.tabhost));             //~1122I~//~1124R~s
    	if (Dump.Y) Dump.println("AjagoView:initTab tabhost="+((Object)tabhost).toString());//~1506R~
        tabhost.setup();            //method by without TabActibity//~1124R~
        tab=tabhost.newTabSpec(Stab_tags[0]);                      //~1122R~
        btn=new Button(AG.context);                                //~1122R~
        btn.setText(AG.tabName_ServerConnections);                 //~1122R~
        tabbtns[0]=btn;                                            //~1122I~
        tab.setIndicator(btn);                                     //~1122R~
        tab.setContent(AG.TabLayoutID_Servers);                    //~1122R~
                                                                   //~1122I~
        tabhost.addTab(tab);                                       //~1122I~
                                                                   //~1122I~
        tab=tabhost.newTabSpec(Stab_tags[1]);                      //~1122R~
        btn=new Button(AG.context);                                //~1122R~
        btn.setText(AG.tabName_PartnerConnections);                //~1122I~
        tabbtns[1]=btn;                                            //~1122I~
        tab.setIndicator(btn);                                     //~1122R~
        tab.setContent(AG.TabLayoutID_Partners);                   //~1122I~
                                                                   //~1122I~
        tabhost.addTab(tab);                                       //~1122I~
        tabhost.setCurrentTab(AG.mainframeTag);
        tabhost.setOnTabChangedListener(AG.ajagoc);  //~1122R~
    }                                                              //~1122I~
//******************                                               //~1122I~
	public void onTabChanged(String Ptag)                          //~1122I~
    {                                                              //~1122I~
    //************                                                 //~1122I~
    	if (Ptag.equals(Stab_tags[0]))                              //~1122I~
        	AG.mainframeTag=0;                                     //~1122I~
        else                                                       //~1122I~
        	AG.mainframeTag=1;                                     //~1122I~
        if (Dump.Y) Dump.println("tab select "+Ptag+",idx="+AG.mainframeTag);//~1506R~
    }                                                              //~1122I~
//******************                                               //~1122I~
	public void initCardPanelLayout(int Ppanelctr)                 //~1125R~
    {                                                              //~1122I~
    	int layoutid;                                              //~1125I~
    //****************                                             //~1125I~
        if (Ppanelctr==0)                                          //~1125R~
            layoutid=AG.frameId_ServerConnections;                 //~1125I~
        else
            layoutid=AG.frameId_PartnerConnections;                //~1125I~
        View layoutview=inflateView(layoutid);               //~1125I~//~1128R~
	    setTabLayout(layoutid,layoutview);                     //~1122R~//~1125R~
	}                                                              //~1125I~
//******************                                               //~1125I~
	public void setTabLayout(int Playoutid,View Playout)           //~1125I~
    {                                                              //~1125I~
    	int containerID;                                           //~1125I~
        LinearLayout container;                                    //~1125I~
    //************                                                 //~1122I~
    	if (Dump.Y) Dump.println("AjagoView:setTabLayoutt Playoutid="+Integer.toHexString(Playoutid));//~1506R~
        if (Playoutid==AG.frameId_ServerConnections)               //~1125I~
        {                                                          //~1122I~
	        containerID=AG.TabLayoutID_Servers;                    //~1122I~
        }                                                          //~1122I~
        else                                                       //~1122I~
        {                                                          //~1122I~
	        containerID=AG.TabLayoutID_Partners;
        }                                                          //~1122I~
        FrameLayout framelayout=tabhost.getTabContentView();       //~1122R~
        container=(LinearLayout)framelayout.findViewById(containerID);       //~1122I~
        container.addView(Playout,0/*pos*/);                       //~1122R~
    }                                                              //~1122I~
//*************************                                        //~1120I~
    @Override                                                      //~1111I~
    public void onClick(View Pview)                                 //~1109I~//~1111I~
	{                                                              //~1109I~//~1111I~
//        AG.ajagoMain.onClick(Pview);                                //~1109I~//~1111I~//~1112R~
	}                                                              //~1109I~//~1111I~
//************                                                     //~1113I~
    static public void setEnabled(View Playout,int Presid)         //~1113I~
    {                                                              //~1113I~
    	View view=(View)Playout.findViewById(Presid);              //~1113I~
    	view.setEnabled(true);                                     //~1113I~
    }                                                              //~1113I~
//************                                                     //~1114I~
    static public void setText(View Playout,int Presid,String Ptext)//~1114I~
    {                                                              //~1114I~
    	TextView tv=(TextView)Playout.findViewById(Presid);            //~1114I~
    	tv.setText(Ptext);                                         //~1114I~
    }                                                              //~1114I~
//************                                                     //~1128I~
    public void windowFocusChanged(boolean Phasfocus)              //~1128R~
    {                                                              //~1128R~
        if (Dump.Y) Dump.println("AjagoView OnFocusChangeListener focus="+Phasfocus);//~1506R~
        Window.onFocusChanged(Phasfocus);                          //~1513R~
    }                                                              //~1128R~
//************                                                     //~1217I~
    public Button getTabButton(int PbuttonNo)	//from Button<--CardPanel//~1217I~
    {                                                              //~1217I~
        if (Dump.Y) Dump.println("getTabButton from CardButton ="+PbuttonNo);//~1506R~
        return tabbtns[PbuttonNo];                                 //~1217I~
    }                                                              //~1217I~
//**********************************************************       //~1314I~
    public static void showToast(int Presid)                       //~1314I~
    {                                                              //~1314I~
		showToast(Presid,"");                                      //~1513I~
    }                                                              //~1314I~
//**********************************************************       //~1514I~
    public static void showToastLong(int Presid)                   //~1514I~
    {                                                              //~1514I~
		showToastLong(Presid,"");                                  //~1514I~
    }                                                              //~1514I~
//**********************************************************       //~1421I~
    public static void showToast(int Presid,String Ptext)          //~1421I~
    {                                                              //~1421I~
        String msg=AG.resource.getString(Presid)+Ptext;            //~1421I~
    	if (Dump.Y) Dump.println("showToast msg="+msg);             //~1513I~
        idLong=false;                                              //~1514I~
    	AjagoUiThread.runOnUiThreadXfer(AG.ajagov,msg);                 //~1513I~
    }                                                              //~1421I~
//**********************************************************       //~1514I~
    public static void showToastLong(int Presid,String Ptext)      //~1514I~
    {                                                              //~1514I~
        String msg=AG.resource.getString(Presid)+Ptext;            //~1514I~
    	if (Dump.Y) Dump.println("showToastLong msg="+msg);        //~1514I~
        idLong=true;                                               //~1514I~
    	AjagoUiThread.runOnUiThreadXfer(AG.ajagov,msg);            //~1514I~
    }                                                              //~1514I~
//**********************************************************       //~1B0cI~
    public static void showToastLong(String Ptext)                 //~1B0cI~
    {                                                              //~1B0cI~
    	if (Dump.Y) Dump.println("showToastLong msg="+Ptext);      //~1B0cI~
        idLong=true;                                               //~1B0cI~
    	AjagoUiThread.runOnUiThreadXfer(AG.ajagov,Ptext);          //~1B0cI~
    }                                                              //~1B0cI~
//**********************************                               //~v106I~
    public static void endGameConfirmed()                          //~v106I~
    {                                                              //~v106I~
    	showToastLong(R.string.endGameConfirmed);                   //~v106R~
	}                                                              //~v106I~
//**********************************                               //~v106I~
    public static void lockContention(String Ptext)                //~v106I~
    {                                                              //~v106I~
    	showToastLong(R.string.lockContention,Ptext);              //~v106I~
	}                                                              //~v106I~
//**********************************                               //~1B0gI~
    public static void memoryShortage(String Ptext)                //~1B0gI~
    {                                                              //~1B0gI~
    	showToastLong(R.string.ErrOutOfMemory,Ptext);                //~1B0gI~
	}                                                              //~1B0gI~
//*********************************************                    //~v110I~
	public void fixOrientation(boolean Pfix)                       //~v110I~
    {                                                              //~v110I~
        int ori2=ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED;      //~v110I~
    	if (Pfix)                                                  //~v110I~
        {                                                          //~v110I~
            int ori=AG.resource.getConfiguration().orientation;    //~v110I~
            int rot=AG.activity.getWindowManager().getDefaultDisplay().getOrientation();//~v110I~
            if (rot==Surface.ROTATION_0||rot==Surface.ROTATION_90) //~v110I~
                if (ori==Configuration.ORIENTATION_LANDSCAPE)      //~v110I~
                    ori2=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE;//~v110I~
                else                                               //~v110I~
                    ori2=ActivityInfo.SCREEN_ORIENTATION_PORTRAIT; //~v110I~
            else                                                   //~v110I~
                if (ori==Configuration.ORIENTATION_LANDSCAPE)      //~v110I~
                    ori2=ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE;//~v110I~
                else                                               //~v110I~
                    ori2=ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT;//~v110I~
        }                                                          //~v110I~
        AG.activity.setRequestedOrientation(ori2);                 //~v110I~
    }                                                              //~v110I~
}//class AjagoView                                                 //~dataR~
