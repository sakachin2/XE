package com.Ajagoc.awt;                                                //~1108R~//~1109R~

import jagoclient.Dump;

import com.Ajagoc.AG;

import android.content.Context;
import android.text.ClipboardManager;
                                                                   //~1212I~
public class Clipboard                    //~1212R~
{   
	ClipboardManager cm=null;
    String data=null;                                              //~1401I~
	public Clipboard()
	{
		cm=(ClipboardManager)AG.ajagoc.getSystemService(Context.CLIPBOARD_SERVICE);
	}
//*for GoFrame                                                     //~1401I~
	public StringSelection getContents(ClipboardOwner Pco)         //~1401I~
	{                                                              //~1401I~
        data=(String)cm.getText();                                         //~1401I~
        if (Dump.Y) Dump.println("Clipboard getText"+data);        //+1506R~
		return new StringSelection(data);                          //~1401I~
	}                                                              //~1401I~
	public void setContents(StringSelection Pss,ClipboardOwner Pco)     //~1212I~//~1401M~
	{                                                              //~1212I~//~1401M~
		cm.setText(Pss.getTransferData(null));                      //~1401I~
	}                                                              //~1212I~//~1401M~

}//class                                                           //~1212R~
