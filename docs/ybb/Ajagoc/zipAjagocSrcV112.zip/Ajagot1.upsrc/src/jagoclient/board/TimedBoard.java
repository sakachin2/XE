package jagoclient.board;

/**
An interface for the GoTimer.
@see jagoclient.board.GoTimer
*/

public interface TimedBoard
{	public void alarm ();
}
