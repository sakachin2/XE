//*CID://+1B1kR~:                                   update#=   25; //+1B1kR~
//****************************************************************************//~@@@1I~
//1B1k 130514 (Bug)PartnerMatch:if undoed Block flag was left,could not move.//+1B1kI~
//1B1j 130514 connection faile exception msg by toast              //~1B1jI~
//1109:130126 notify board closed when when stop app               //~v110I~
//1106:130126 Gamequestion popup even after IP connection lost     //~v110I~
//1103:130124 board stop timing(avoid exception)                   //~v110I~
//1081:121213 partner-match:when server requested endgame,Block=true remains and//~v108I~
//            on next match on same connection(same PartnerFrame),client setstone is blocked//~v108I~
//            (                                                    //~v108I~
//            endgame by interrupt @@endgame set Block=true after call EndGameQuestion//~v108I~
//            EndGameQuestion call doendgame/declineendgame(set Block=false)//~v108I~
//            modal dialog is protected to return before reply,so results Block=true)//~v108I~
//            )                                                    //~v108I~
//1071:121204 partner connection using Bluetooth SPP               //~v107I~
//*@@@1 20110430 FunctionKey support                               //~@@@1I~
//****************************************************************************//~@@@1I~
package jagoclient.partner;

import jagoclient.CloseConnection;
import jagoclient.Dump;
import jagoclient.Global;
import jagoclient.dialogs.Help;
import jagoclient.dialogs.Message;
import jagoclient.dialogs.Question;
import jagoclient.gui.ButtonAction;
import jagoclient.gui.CloseFrame;
import jagoclient.gui.HistoryTextField;
import jagoclient.gui.MenuItemAction;
import jagoclient.gui.MyMenu;
import jagoclient.gui.MyPanel;
import jagoclient.gui.Panel3D;

//import java.awt.BorderLayout;
//import java.awt.Color;
//import java.awt.FileDialog;
//import java.awt.Menu;
//import java.awt.MenuBar;
//import java.awt.Panel;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;

//import android.view.Menu;

import com.Ajagoc.AG;                                              //~v110I~
import com.Ajagoc.AjagoView;                                       //~v110I~
import com.Ajagoc.R;                                               //~v110I~
import com.Ajagoc.awt.BorderLayout;
import com.Ajagoc.awt.Color;
import com.Ajagoc.awt.FileDialog;
import com.Ajagoc.awt.KeyEvent;
import com.Ajagoc.awt.KeyListener;
import com.Ajagoc.awt.MenuBar;
import com.Ajagoc.awt.Panel;
import com.Ajagoc.awt.Menu;

import rene.util.list.ListClass;
import rene.util.list.ListElement;
import rene.util.parser.StringParser;
//import rene.viewer.SystemViewer;                                 //~1318R~
//import rene.viewer.Viewer;                                       //~1318R~
import com.Ajagoc.rene.viewer.Viewer;                              //~1318I~
import com.Ajagoc.rene.viewer.SystemViewer;                        //~1318I~

class PartnerMove
{	public String Type;
	public int P1,P2,P3,P4,P5,P6;
	public PartnerMove (String type, int p1, int p2, int p3, int p4, int p5, int p6)
	{	Type=type; P1=p1; P2=p2; P3=p3; P4=p4; P5=p5; P6=p6;
	}
	public PartnerMove (String type, int p1, int p2, int p3, int p4)
	{	Type=type; P1=p1; P2=p2; P3=p3; P4=p4;
	}
}

/**
The partner frame contains a simple chat dialog and a button
to start a game or restore an old game. This class contains an
interpreters for the partner commands.
*/

public class PartnerFrame extends CloseFrame
	implements KeyListener                                         //~@@@1I~
//{	BufferedReader In;                                             //~v107R~
{	                                                               //~v107I~
	protected BufferedReader In;                                   //~v107I~
//	PrintWriter Out;                                               //~v107R~
  	protected PrintWriter Out;                                      //~v107I~
//	Viewer Output;                                                 //~v107R~
	protected Viewer Output;                                       //~v107I~
//  HistoryTextField Input;                                        //~v107R~
    protected HistoryTextField Input;                              //~v107I~
	Socket Server;
//	PartnerThread PT;                                              //~v107R~
	protected PartnerThread PT;                                    //~v107I~
	public PartnerGoFrame PGF;
	boolean Serving;
	boolean Block;
	ListClass Moves;
	String Dir;
	String Encoding;                                               //~1109I~

	public PartnerFrame (String name, boolean serving)
	{	super(name);
		Panel p=new MyPanel();
		Serving=serving;
		MenuBar menu=new MenuBar();
		setMenuBar(menu);
		Menu help=new MyMenu(Global.resourceString("Help"));
		help.add(new MenuItemAction(this,Global.resourceString("Partner_Connection")));
		menu.setHelpMenu(help);
		p.setLayout(new BorderLayout());
		p.add("Center",Output=Global.getParameter("systemviewer",false)?new SystemViewer():new Viewer());
		Output.setFont(Global.Monospaced);
		p.add("South",Input=new HistoryTextField(this,"Input"));
		add("Center",p);
		Panel p1=new MyPanel();
		p1.add(new ButtonAction(this,Global.resourceString("Game")));
		p1.add(new ButtonAction(this,Global.resourceString("Restore_Game")));
		add("South",new Panel3D(p1));
		PGF=null;
		Block=false;
		Dir="";
		Moves=new ListClass();
		seticon("iconn.gif");
		addKeyListener(this);                                      //~@@@1I~
        AG.aPartnerFrame=this;                                     //~v110R~
	}

	//*************************************************************************//~1109I~
	public boolean connect (String s, int p,String Pencoding)      //~1109I~
    {                                                              //~1109I~
    	Encoding=Pencoding;                                        //~1109I~
        boolean rc=connect(s,p);                                   //~1109I~
        Encoding=null;                                             //~1109I~
        return rc;                                                 //~1109I~
    }                                                              //~1109I~
	//*************************************************************************//~1109I~
	public boolean connect (String s, int p)
	{	if (Dump.Y) Dump.println("Starting partner connection");   //~@@@1R~
		try
		{	Server=new Socket(s,p);
        	boolean encode=(Encoding!=null & !Encoding.equals(""));  //~1B0cI~//~1109I~
          if (encode)                                              //~1B0cI~//~1109I~
          {                                                        //~1B0cI~//~1109I~
          	try                                                    //~1B0cI~//~1109I~
            {                                                      //~1B0cI~//~1109I~
                Out=new PrintWriter(                               //~1B0cI~//~1109I~
                        new OutputStreamWriter(                    //~1B0cI~//~1109I~
                    					new DataOutputStream(Server.getOutputStream()) //~1B0cI~//~1109I~
                                               ,Encoding)          //~1B0cI~//~1109I~
                                    ,true);                        //~1B0cI~//~1109I~
                In=new BufferedReader(new InputStreamReader(       //~1B0cI~//~1109I~
                    					new DataInputStream(Server.getInputStream())//~1109I~
                                               				,Encoding)//~1109I~
									);                             //~1109I~
            }                                                      //~1B0cI~//~1109I~
			catch (UnsupportedEncodingException e)                 //~1B0cI~//~1109I~
			{                                                      //~1B0cI~//~1109I~
            	AjagoView.showToastLong(AG.resource.getString(R.string.ErrEncoding,Encoding));//~1109I~
				return false;                                      //~1109I~
            }                                                      //~1109I~
          }                                                        //~1B0cI~//~1109I~
          else                                                     //~1B0cI~//~1109I~
          {                                                        //~1B0cI~//~1109I~
			Out=new PrintWriter(
				new DataOutputStream(Server.getOutputStream()),true);
			In=new BufferedReader(new InputStreamReader(
			    new DataInputStream(Server.getInputStream())));
          }                                                        //~1109I~
		}
		catch (Exception e)
//		{	return false;                                          //~1B1jR~
  		{                                                          //~1B1jR~
        	if (Dump.Y) Dump.println("cause="+e.getCause()+",msg="+e.getMessage());//~1B1jR~
            String msg=e.getMessage();                             //~1B1jI~
            if (msg!=null)                                         //~1B1jI~
	            AjagoView.showToastLong(msg);                      //~1B1jI~
            Dump.println(e,"PartnerFrame:connect "+s+",port="+p);  //~1B1jR~
  		 	return false;                                          //~1B1jR~
		}
		PT=new PartnerThread(In,Out,Input,Output,this);
		PT.start();
		Out.println("@@name "+
			Global.getParameter("yourname","No Name"));
		show();
		return true;
	}

	public boolean connectvia (String server, int port,
		String relayserver, int relayport)
	{	try
		{	Server=new Socket(relayserver,relayport);
			Out=new PrintWriter(
				new DataOutputStream(Server.getOutputStream()),true);
			In=new BufferedReader(new InputStreamReader(
			    new DataInputStream(Server.getInputStream())));
		}
		catch (Exception e)
		{	return false;
		}
		Out.println(server);
		Out.println(""+port);
		PT=new PartnerThread(In,Out,Input,Output,this);
		PT.start();
		Out.println("@@name "+
			Global.getParameter("yourname","No Name"));
		show();
		return true;
	}

	public void open (Socket server)
	{	if (Dump.Y) Dump.println("Starting partner server");       //~@@@1R~
		Server=server;
		try
		{	Out=new PrintWriter(
				new DataOutputStream(Server.getOutputStream()),true);
			In=new BufferedReader(new InputStreamReader(
			    new DataInputStream(Server.getInputStream())));
		}
		catch (Exception e)
		{	if (Dump.Y) Dump.println("---> no connection");        //~@@@1R~
			new Message(this,Global.resourceString("Got_no_Connection_"));
			return;
		}
		PT=new PartnerThread(In,Out,Input,Output,this);
		PT.start();
	}

	public void doAction (String o)
	{	if ("Input".equals(o))
		{	Out.println(Input.getText());
			Input.remember(Input.getText());
			Output.append(Input.getText()+"\n",Color.green.darker());
			Input.setText("");
		}
		else if (Global.resourceString("Game").equals(o))
//      {   new GameQuestion(this);                                //~v110R~
        {                                                          //~v110I~
          	if (PT!=null && PT.isAlive())                          //~v110I~
				new GameQuestion(this);                            //~v110I~
            else                                                   //~v110I~
            	AjagoView.showToast(R.string.NoPartnerConnection); //~v110I~
		}
		else if (Global.resourceString("Restore_Game").equals(o))
		{	if (!Block)
			{	if (PGF==null)
				{	Out.println("@@restore");
					Block=true;
				}
				else
				{	new Message(this,Global.resourceString(
						"You_have_already_a_game_"));
				}
			}
			
		}
		else if (Global.resourceString("Partner_Connection").equals(o))
		{	new Help("partner");
		}
		else super.doAction(o);
	}

	public void doclose ()
	{	Global.notewindow(this,"partner");	
		Out.println("@@@@end");
		Out.close();
		new CloseConnection(Server,In);
		super.doclose();
	}

	public boolean close ()
	{	if (PT.isAlive())
		{	new ClosePartnerQuestion(this);
			return false;
		}
		else return true;
	}

	/**
	The interpreter for the partner commands (all start with @@).
	*/
	public void interpret (String s)
//  {	if (s.startsWith("@@name"))                                //~v107R~
	{                                                              //~v107I~
        if (Dump.Y) Dump.println("PartnetFrame interpret:"+s);     //~v107I~
		if (s.startsWith("@@name"))                                //~v107I~
		{	StringParser p=new StringParser(s);
			p.skip("@@name");
			setTitle(Global.resourceString("Connection_to_")+p.upto('!'));
        	if (Dump.Y) Dump.println("PartnetFrame setTitle:"+Global.resourceString("Connection_to_")+p.upto('!'));//~v107I~
		}
		else if (s.startsWith("@@board"))
		{	if (PGF!=null) return;
			StringParser p=new StringParser(s);
			p.skip("@@board");
			String color=p.parseword();
			int C;
			if (color.equals("b")) C=1;
			else C=-1;
			int Size=p.parseint();
			int TotalTime=p.parseint();
			int ExtraTime=p.parseint();
			int ExtraMoves=p.parseint();
			int Handicap=p.parseint();
			new BoardQuestion(this,Size,color,Handicap,TotalTime,
				ExtraTime,ExtraMoves);
		}
		else if (s.startsWith("@@!board"))
		{	if (PGF!=null) return;
			StringParser p=new StringParser(s);
			p.skip("@@!board");
			String color=p.parseword();
			int C;
			if (color.equals("b")) C=1;
			else C=-1;
			int Size=p.parseint();
			int TotalTime=p.parseint();
			int ExtraTime=p.parseint();
			int ExtraMoves=p.parseint();
			int Handicap=p.parseint();
			PGF=new PartnerGoFrame(this,Global.resourceString("Partner_Game"),
				C,Size,TotalTime*60,ExtraTime*60,ExtraMoves,Handicap);
			Out.println("@@start");
			Block=false;
			Moves=new ListClass();
			Moves.append(new ListElement(
				new PartnerMove("board",C,Size,
					TotalTime,ExtraTime,ExtraMoves,Handicap)));
		}
		else if (s.startsWith("@@-board"))
		{	new Message(this,Global.resourceString("Partner_declines_the_game_"));
			Block=false;
		}		
		else if (s.startsWith("@@start"))
		{	if (PGF==null) return;
			PGF.start();
			Out.println("@@!start");
		}
		else if (s.startsWith("@@!start"))
		{	if (PGF==null) return;
			PGF.start();
		}
		else if (s.startsWith("@@move"))
		{	if (PGF==null) return;
			StringParser p=new StringParser(s);
			p.skip("@@move");
			String color=p.parseword();
			int i=p.parseint(),j=p.parseint();
			int bt=p.parseint(),bm=p.parseint();
			int wt=p.parseint(),wm=p.parseint();
			if (Dump.Y) Dump.println("Move of "+color+" at "+i+","+j);//~@@@1R~
			if (color.equals("b"))
			{	if (PGF.maincolor()<0) return;
				PGF.black(i,j);
				Moves.append(new ListElement
					(new PartnerMove("b",i,j,bt,bm,wt,wm)));
			}
			else
			{	if (PGF.maincolor()>0) return;
				PGF.white(i,j);
				Moves.append(new ListElement
					(new PartnerMove("w",i,j,bt,bm,wt,wm)));
			}
			PGF.settimes(bt,bm,wt,wm);
			Out.println("@@!move "+color+" "+i+" "+j+" "+
				bt+" "+bm+" "+wt+" "+wm);
		}
		else if (s.startsWith("@@!move"))
		{	if (PGF==null) return;
			StringParser p=new StringParser(s);
			p.skip("@@!move");
			String color=p.parseword();
			int i=p.parseint(),j=p.parseint();
			int bt=p.parseint(),bm=p.parseint();
			int wt=p.parseint(),wm=p.parseint();
			if (Dump.Y) Dump.println("Move of "+color+" at "+i+","+j);//~@@@1R~
			if (color.equals("b"))
			{	if (PGF.maincolor()<0) return;
				PGF.black(i,j);
				Moves.append(new ListElement
					(new PartnerMove("b",i,j,bt,bm,wt,wm)));
			}
			else
			{	if (PGF.maincolor()>0) return;
				PGF.white(i,j);
				Moves.append(new ListElement
					(new PartnerMove("w",i,j,bt,bm,wt,wm)));
			}
			PGF.settimes(bt,bm,wt,wm);
		}
		else if (s.startsWith("@@pass"))
		{	if (PGF==null) return;
			StringParser p=new StringParser(s);
			p.skip("@@pass");
			int bt=p.parseint(),bm=p.parseint();
			int wt=p.parseint(),wm=p.parseint();
			if (Dump.Y) Dump.println("Pass");                      //~@@@1R~
			PGF.dopass();
			PGF.settimes(bt,bm,wt,wm);
			Moves.append(new ListElement
				(new PartnerMove("pass",bt,bm,wt,wm)));
			Out.println("@@!pass "+bt+" "+bm+" "+wt+" "+wm);
		}
		else if (s.startsWith("@@!pass"))
		{	if (PGF==null) return;
			StringParser p=new StringParser(s);
			p.skip("@@!pass");
			int bt=p.parseint(),bm=p.parseint();
			int wt=p.parseint(),wm=p.parseint();
			if (Dump.Y) Dump.println("Pass");                      //~@@@1R~
			PGF.dopass();
			Moves.append(new ListElement
				(new PartnerMove("pass",bt,bm,wt,wm)));
			PGF.settimes(bt,bm,wt,wm);
		}
		else if (s.startsWith("@@endgame"))
		{	if (PGF==null) return;
  			Block=true;                                            //~v108I~
			new EndGameQuestion(this);
//			Block=true;                                            //~v108R~
		}
		else if (s.startsWith("@@!endgame"))
		{	if (PGF==null) return;
			PGF.doscore();
			Block=false;
		}
		else if (s.startsWith("@@-endgame"))
		{	if (PGF==null) return;
			new Message(this,"Partner declines game end!");
			Block=false;
		}
		else if (s.startsWith("@@result"))
		{	if (PGF==null) return;
			StringParser p=new StringParser(s);
			p.skip("@@result");
			int b=p.parseint();
			int w=p.parseint();
			if (Dump.Y) Dump.println("Result "+b+" "+w);           //~@@@1R~
			new ResultQuestion(this,Global.resourceString("Accept_result__B_")+b+Global.resourceString("__W_")+w+"?",b,w);
			Block=true;
		}
		else if (s.startsWith("@@!result"))
		{	if (PGF==null) return;
			StringParser p=new StringParser(s);
			p.skip("@@!result");
			int b=p.parseint();
			int w=p.parseint();
			if (Dump.Y) Dump.println("Result "+b+" "+w);           //~@@@1R~
			Output.append(Global.resourceString("Game_Result__B_")+b+Global.resourceString("__W_")+w+"\n",Color.green.darker());
			new Message(this,Global.resourceString("Result__B_")+b+Global.resourceString("__W_")+w+" was accepted!");
			Block=false;
		}
		else if (s.startsWith("@@-result"))
		{	if (PGF==null) return;
			new Message(this,Global.resourceString("Partner_declines_result_"));
			Block=false;
		}
		else if (s.startsWith("@@undo"))
		{	if (PGF==null) return;
  			Block=true;	//UndoQuestion is modal on subthread(wait dismiss)//+1B1kI~
			new UndoQuestion(this);
//			Block=true;                                            //+1B1kR~
		}
		else if (s.startsWith("@@-undo"))
		{	if (PGF==null) return;
			new Message(this,Global.resourceString("Partner_declines_undo_"));
			Block=false;
		}
		else if (s.startsWith("@@!undo"))
		{	if (PGF==null) return;
			PGF.undo(2);
			Moves.remove(Moves.last());
			Moves.remove(Moves.last());
			PGF.addothertime(30);
			Block=false;
		}
		else if (s.startsWith("@@adjourn"))
		{	adjourn();
		}
		else if (s.startsWith("@@restore"))
		{	Question Q=new Question(this,
				Global.resourceString("Your_partner_wants_to_restore_a_game_"),
				Global.resourceString("Accept"),null,true);
			Q.show();
			if (Q.result()) acceptrestore();
			else declinerestore();
		}
		else if (s.startsWith("@@-restore"))
		{	new Message(this,Global.resourceString("Partner_declines_restore_"));
			Block=false;
		}
		else if (s.startsWith("@@!restore"))
		{	dorestore();
			Block=false;
		}
		else if (s.startsWith("@@@"))
		{	moveinterpret(s.substring(3),false);
		}
	}

	public boolean moveset (String c, int i, int j, int bt, int bm,
		int wt, int wm)
	{	if (Block) return false;
		Out.println("@@move "+c+" "+i+" "+j+" "+bt+" "+bm+" "+wt+" "+wm);
		return true;
	}

	public void out (String s)
	{	Out.println(s);
	}

	public void refresh ()
	{
	}

	public void set (int i, int j)
	{
	}

	public void pass (int bt, int bm, int wt, int wm)
	{	Out.println("@@pass "+bt+" "+bm+" "+wt+" "+wm);
	}

	public void endgame ()
	{	if (Block) return;
		Block=true;
		Out.println("@@endgame");
	}

	public void doendgame ()
	{	Out.println("@@!endgame");
		PGF.doscore();
		Block=false;
	}

	public void declineendgame ()
	{	Out.println("@@-endgame");
		Block=false;
	}

	public void doresult (int b, int w)
	{	Out.println("@@!result "+b+" "+w);
		Output.append(Global.resourceString("Game_Result__B_")+b+Global.resourceString("__W_")+w+"\n",Color.green.darker());
		Block=false;
	}

	public void declineresult ()
	{	Out.println("@@-result");
		Block=false;
	}

	public void undo ()
	{	if (Block) return;
		Block=true;
		Out.println("@@undo");
	}

	public void doundo ()
	{	Out.println("@@!undo");
		PGF.undo(2);
		Moves.remove(Moves.last());
		Moves.remove(Moves.last());
		Block=false;
		PGF.addtime(30);
	}

	public void declineundo ()
	{	Out.println("@@-undo");
		Block=false;
	}

	public void dorequest (int s, String c, int h, int tt, int et, int em)
	{	Out.println("@@board "+c+" "+s+" "+tt+" "+et+" "+em+" "+h);
		Block=true;
	}

	public void doboard (int Size, String C, int Handicap,
			int TotalTime, int ExtraTime, int ExtraMoves)
	{	PGF=new PartnerGoFrame(this,"Partner Game",
			C.equals("b")?-1:1,Size,TotalTime*60,ExtraTime*60,ExtraMoves,Handicap);
		if (C.equals("b")) Out.println("@@!board b"+
			" "+Size+" "+TotalTime+" "+ExtraTime+" "+ExtraMoves+" "+Handicap);
		else Out.println("@@!board w"+
			" "+Size+" "+TotalTime+" "+ExtraTime+" "+ExtraMoves+" "+Handicap);
		Moves=new ListClass();
		Moves.append(new ListElement(
			new PartnerMove("board",C.equals("b")?-1:1,
				Size,TotalTime,ExtraTime,ExtraMoves,Handicap)));
	}

	public void declineboard ()
	{	Out.println("@@-board");
	}

	public void boardclosed (PartnerGoFrame pgf)
	{	if (PGF==pgf)
		{	Out.println("@@adjourn");
			savemoves();
		}
	}

	public void adjourn ()
	{	new Message(this,Global.resourceString("Your_Partner_closed_the_board_"));
        stopTimer();                                               //~v110I~
		savemoves();
		PGF=null;
	}

	public void savemoves ()
	{	Question Q=new Question(this,
			Global.resourceString("Save_this_game_for_reload_"),
			Global.resourceString("Yes"),null,true);
		Q.show();
		if (Q.result()) dosave();
	}

	public void dosave ()
	{	FileDialog fd=new FileDialog(this,Global.resourceString("Save_Game"),FileDialog.SAVE);//~@@@1R~
		if (!Dir.equals("")) fd.setDirectory(Dir);
		fd.setFile("*.sto");
		fd.show();
		String fn=fd.getFile();
		if (fn==null) return;
		Dir=fd.getDirectory();
		if (fn.endsWith(".*.*")) // Windows 95 JDK bug
		{	fn=fn.substring(0,fn.length()-4);
		}
		try // print out using the board class
		{	PrintWriter fo=
				new PrintWriter(new FileOutputStream(fd.getDirectory()+fn),true);
			ListElement lm=Moves.first();
			while (lm!=null)
			{	PartnerMove m=(PartnerMove)lm.content();
				fo.println(m.Type+" "+m.P1+" "+m.P2+" "+m.P3+" "+m.P4+
					" "+m.P5+" "+m.P6);
				lm=lm.next();
			}
			fo.close();
		}
		catch (IOException ex)
		{}
	}

	void acceptrestore ()
	{	Out.println("@@!restore");
	}

	void declinerestore ()
	{	Out.println("@@-restore");
	}

	void dorestore ()
	{	if (PGF!=null) return;
		FileDialog fd=new FileDialog(this,Global.resourceString("Load_Game"),FileDialog.LOAD);
		if (!Dir.equals("")) fd.setDirectory(Dir);
		fd.setFile("*.sto");
		fd.show();
		String fn=fd.getFile();
		if (fn==null) return;
		Dir=fd.getDirectory();
		if (fn.endsWith(".*.*")) // Windows 95 JDK bug
		{	fn=fn.substring(0,fn.length()-4);
		}
		try // print out using the board class
		{	BufferedReader fi=new BufferedReader(new InputStreamReader(
				new DataInputStream(new FileInputStream(fd.getDirectory()+fn))));
			Moves=new ListClass();
			while (true)
			{	String s=fi.readLine();
				if (s==null) break;
				StringParser p=new StringParser(s);
				Out.println("@@@"+s);
				moveinterpret(s,true);
			}
			if (PGF!=null) Out.println("@@start");
			fi.close();
		}
		catch (IOException ex)
		{}
	}

	void moveinterpret (String s, boolean fromhere)
	{	StringParser p=new StringParser(s);
		String c=p.parseword();
		int p1=p.parseint();
		int p2=p.parseint();
		int p3=p.parseint();
		int p4=p.parseint();
		int p5=p.parseint();
		int p6=p.parseint();
		if (c.equals("board"))
		{	PGF=new PartnerGoFrame(this,Global.resourceString("Partner_Game"),
				fromhere?p1:-p1,p2,p3*60,p4*60,p5,p6);
			PGF.setHandicap();
		}
		else if (PGF!=null && c.equals("b"))
		{	PGF.black(p1,p2);
			PGF.settimes(p3,p4,p5,p6);
		}
		else if (PGF!=null && c.equals("w"))
		{	PGF.white(p1,p2);
			PGF.settimes(p3,p4,p5,p6);
		}
		else if (PGF!=null && c.equals("pass"))
		{	PGF.pass();
			PGF.settimes(p1,p2,p3,p4);
		}
		Moves.append(new ListElement(
			new PartnerMove(c,p1,p2,p3,p4,p5,p6)));
	}
//*FunctionKeySupport like as ConnectionFrame *******              //~@@@1I~
	public void keyPressed (KeyEvent e) {	}                      //~@@@1I~
	public void keyTyped (KeyEvent e) {	}                          //~@@@1I~
	public void keyReleased (KeyEvent e)                           //~@@@1I~
	{	String s=Global.getFunctionKey(e.getKeyCode());            //~@@@1I~
		if (s.equals("")) return;                                  //~@@@1I~
		Input.setText(s);                                          //~@@@1I~
	}                                                              //~@@@1I~
//**************************************************************************//~v110I~
    public void stopTimer()                                        //~v110I~
    {                                                              //~v110I~
		if (Dump.Y) Dump.println("PartnerFrame stopTimer");        //~v110I~
    	if (PGF!=null)                                             //~v110I~
        	if (PGF.Timer!=null)                                   //~v110I~
            	if (PGF.Timer.isAlive())                           //~v110I~
                {                                                  //~v110I~
				    if (Dump.Y) Dump.println("PartnerFrame Timer Stop");//~v110R~
                	PGF.Timer.stopit();                            //~v110I~
                }                                                  //~v110I~
    }                                                              //~v110I~
//**************************************************************************//~v110I~
//*from Ajagoc at appStop,send @@adjourn and cose out to notify termination//~v110I~
//**************************************************************************//~v110I~
    public void closeStream()                                      //~v110I~
    {                                                              //~v110I~
	    if (Dump.Y) Dump.println("PartnerFrame close Stream");     //~v110I~
        stopTimer();                                               //~v110M~
        if (Out!=null)                                             //~v110I~
        {                                                          //~v110I~
            if (Out!=null)                                         //~v110I~
            {                                                      //~v110I~
			    if (Dump.Y) Dump.println("out @@adjourn");         //~v110I~
				Out.println("@@adjourn");                          //~v110I~
			    if (Dump.Y) Dump.println("out close");             //~v110I~
                Out.close();                                       //~v110I~
            }                                                      //~v110I~
        }                                                          //~v110I~
    }                                                              //~v110I~
}

