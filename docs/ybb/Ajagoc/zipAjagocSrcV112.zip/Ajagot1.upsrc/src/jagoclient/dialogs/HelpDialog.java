//*CID://+1B1gR~:                             update#=    3;       //~1B1gI~
//**************************************************************************//~1B1gI~
//1B1g 130511 Button on Help Frame for modified Help text for Ajagoc//~1B1gI~
//**************************************************************************//~1B1gI~
package jagoclient.dialogs;

//import java.awt.*;                                               //~1418R~
import java.io.*;

import android.view.View;

import com.Ajagoc.AG;
import com.Ajagoc.R;
import com.Ajagoc.awt.Frame;
import com.Ajagoc.awt.Panel;
import com.Ajagoc.rene.viewer.SystemViewer;                        //~1327I~
import com.Ajagoc.rene.viewer.Viewer;                              //~1327I~

import jagoclient.gui.*;
import jagoclient.Global;

//import rene.viewer.*;                                            //~1327R~

/**
The same as Help.java but as a dialog. This is for giving help in
modal dialogs. 
@see jagoclient.dialogs.Help
*/

public class HelpDialog extends CloseDialog
{	Viewer V; // The viewer
	Frame F;
    private final static String SUFFIX_AJAGOC="Ajagoc";            //~1B1gI~
    private boolean updateForAjagoc;                               //~1B1gI~
    private String actionAjagoc,subjectAjagoc="";                  //~1B1gI~
	/**
	Display the help from subject.txt,Global.url()/subject.txt
	or from the ressource /subject.txt.
	*/
	public HelpDialog (Frame f, String subject)
	{	super(f,Global.resourceString("Help"),true);
		F=f;
		V=Global.getParameter("systemviewer",false)?new SystemViewer():new Viewer();
		V.setFont(Global.Monospaced);
		V.setBackground(Global.gray);
        updateForAjagoc=isExistUpdateForAjagoc(subject);           //~1B1gI~
        actionAjagoc=AG.resource.getString(R.string.HelpForAjagoc);//~1B1gI~
		try
		{	BufferedReader in;
			String s;
			try
//@@@@  	{	in=Global.getStream(                               //~1327R~
        	{	in=Global.getEncodedStream(        //like as Help.java;required to display locale language//~1327I~
					"jagoclient/helptexts/"+subject+Global.resourceString("HELP_SUFFIX")+".txt");
				s=in.readLine();
			}
			catch (Exception e)
			{	try
//@@@@ 			{	in=Global.getStream(                           //~1327R~
    			{	in=Global.getEncodedStream(                    //~1327I~
						subject+Global.resourceString("HELP_SUFFIX")+".txt");
					s=in.readLine();
				}
				catch (Exception ex)
//@@@@  		{	in=Global.getStream("jagoclient/helptexts/"+subject+".txt");//~1327R~
    			{	in=Global.getEncodedStream("jagoclient/helptexts/"+subject+".txt");//~1327I~
					s=in.readLine();
				}
			}
			while (s!=null)
			{	V.appendLine(s);
				s=in.readLine();
			}
			in.close();
		}
		catch (Exception e)
		{	new Message(Global.frame(),
				Global.resourceString("Could_not_find_the_help_file_"));
			doclose();
			return;
		}
		display();
	}
	
	public void doclose ()
	{	setVisible(false); dispose();
	}
	
	void display ()
	{	Global.setwindow(this,"help",500,400);
		add("Center",V);
		Panel p=new MyPanel();
//  	p.add(new ButtonAction(this,Global.resourceString("Close")));//+1B1gR~
        String closelabel=Global.resourceString("Close");          //+1B1gI~
        ButtonAction closebutton=new ButtonAction(this,closelabel);    //+1B1gI~
    	p.add(closebutton);                                        //+1B1gI~
		closebutton.setText(closelabel); 	//Button dose not set if AG.currentDialog!=null//+1B1gI~
        if (updateForAjagoc)                                       //~1B1gI~
        {                                                          //~1B1gI~
        	ButtonAction morehelp=new ButtonAction(this,actionAjagoc);//~1B1gI~
			morehelp.setVisibility(View.VISIBLE);                  //~1B1gI~
			morehelp.setText(actionAjagoc); 	//Button dose not set if AG.currentDialog!=null//~1B1gI~
        }                                                          //~1B1gI~
		add("South",new Panel3D(p));
		setVisible(true);
	}
	public void doAction (String o)
	{	Global.notewindow(this,"help");
    	if (o.equals(actionAjagoc))                                //~1B1gI~
        {                                                          //~1B1gI~
        	new HelpDialog(new Frame(),subjectAjagoc);             //~1B1gI~
        }                                                          //~1B1gI~
        else                                                       //~1B1gI~
		super.doAction(o);
	}
    //***********************************************************  //~1B1gI~
	private boolean isExistUpdateForAjagoc(String subject)         //~1B1gI~
	{                                                              //~1B1gI~
    	boolean rc=false;                                          //~1B1gI~
    	subjectAjagoc=subject+SUFFIX_AJAGOC;                       //~1B1gI~
		String fnm="jagoclient/helptexts/"+subjectAjagoc+".txt";   //~1B1gI~
		BufferedReader in;                                         //~1B1gI~
		try                                                        //~1B1gI~
		{                                                          //~1B1gI~
			in=Global.getEncodedStream(fnm);                       //~1B1gI~
			in.close();                                            //~1B1gI~
            rc=true;                                               //~1B1gI~
		}                                                          //~1B1gI~
		catch (Exception e)                                        //~1B1gI~
		{                                                          //~1B1gI~
		}                                                          //~1B1gI~
        return rc;                                                 //~1B1gI~
	}                                                              //~1B1gI~
}
