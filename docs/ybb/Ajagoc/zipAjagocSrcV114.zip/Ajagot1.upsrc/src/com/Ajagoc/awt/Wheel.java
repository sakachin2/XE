package com.Ajagoc.awt;                                                //~1108R~//~1109R~

import rene.viewer.WheelListener;


public class Wheel                                                 //~1213R~
{                                                                  //~1111I~
//    public Wheel(MouseListener Pmwl)                          //~1213I~//+1214R~
//    {                                                              //~1213I~//+1214R~
//    }                                                              //~1213I~//+1214R~
	public Wheel(WheelListener Pwl)                                //~1214I~
    {                                                              //~1214I~
    }                                                              //~1214I~
}
