package com.Ajagoc.awt;                                                //~1108R~//~1109R~

public class FlowLayout                                            //+1124R~
{                                                                  //~1111I~
	public static final int CENTER=1;    //temporary               //+1124I~
    public FlowLayout()                                                 //~1111I~//+1124R~
    {                                                              //~1111I~
    }                                                              //~1111I~
    public void setAlignment(int P1)                               //+1124I~
    {                                                              //+1124I~
    }                                                              //+1124I~
}
