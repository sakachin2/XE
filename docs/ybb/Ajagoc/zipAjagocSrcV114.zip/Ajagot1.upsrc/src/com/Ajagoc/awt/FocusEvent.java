package com.Ajagoc.awt;                                                //~1108R~//~1109R~//+1213I~
public class FocusEvent/*extends ComponentEvent*/                  //~1213I~
{                                                                  //~1213I~
}                                                                  //~1213I~
