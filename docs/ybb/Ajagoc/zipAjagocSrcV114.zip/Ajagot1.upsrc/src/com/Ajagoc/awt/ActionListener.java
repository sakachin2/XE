package com.Ajagoc.awt;

public interface ActionListener                                    //~1112I~
{                                                                  //~1112I~
    void actionPerformed (ActionEvent e);                          //+1112R~
}                                                                  //~1112I~