//*CID://+v110R~:                                   update#=   33; //~v107R~//~v110R~
//******************************************************************************************************************//~v107I~
//1102:130123 bluetooth became unconnectable after some stop operation//~v110I~
//1071:121204 partner connection using Bluetooth SPP               //~v107I~
//******************************************************************************************************************//~v107I~
//*@@@1 20110430 FunctionKey support                               //~@@@1I~
//****************************************************************************//~@@@1I~
package com.Ajagoc.jagoclient.partner;                             //~v107R~

import jagoclient.Dump;
import jagoclient.Global;
import jagoclient.dialogs.Message;
//import jagoclient.gui.HistoryTextField;
//import jagoclient.partner.PartnerGoFrame;
//import jagoclient.partner.PartnerThread;                         //~v107R~
import com.Ajagoc.AG;
import com.Ajagoc.jagoclient.partner.PartnerThread;                //~v107I~

//import java.awt.BorderLayout;
//import java.awt.Color;
//import java.awt.FileDialog;
//import java.awt.Menu;
//import java.awt.MenuBar;
//import java.awt.Panel;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import android.bluetooth.BluetoothSocket;

//import rene.util.list.ListClass;
//import rene.viewer.SystemViewer;                                 //~1318R~
//import rene.viewer.Viewer;                                       //~1318R~
//import com.Ajagoc.rene.viewer.Viewer;                              //~1318I~

/**
The partner frame contains a simple chat dialog and a button
to start a game or restore an old game. This class contains an
interpreters for the partner commands.
*/

//public class PartnerFrame extends CloseFrame                     //~v107R~
public class PartnerFrame extends jagoclient.partner.PartnerFrame  //~v107R~
{                                                                  //~v107R~
//  Socket Server;                                                 //~v107R~
    private BluetoothSocket Server;                                        //~v107I~
    private String localDeviceName,remoteDeviceName;                                //~v107R~
	public static final String CONNECT_TO_BT="BT:";	//chk frameid at awt/Frame//~v107I~

	public PartnerFrame (String name,String Premotedevicename,String Plocaldevicename,boolean serving,BluetoothSocket PBTSocket)//~v107R~
    {                                                              //~v107I~
    	super(name+CONNECT_TO_BT+Premotedevicename,serving);       //~v107R~
        localDeviceName=Plocaldevicename;                          //~v107R~
        remoteDeviceName=Premotedevicename;                        //~v107I~
		Server=PBTSocket;                                          //~v107R~
        AG.aPartnerFrame=this;                                     //~v110I~
		if (Dump.Y) Dump.println("Ajagoc:PartnerFrame constructor namd="+name+",remote="+Premotedevicename+",local="+Plocaldevicename);//~v107R~
	}

//****************************************************************************//~v107I~
//*from BTControl                                                  //~v107I~
//****************************************************************************//~v107I~
	public boolean connect ()                                      //~v107R~
	{                                                              //~v107R~
		if (Dump.Y) Dump.println("Ajagoc:PartnerFrame connect localdevicename="+localDeviceName);//~v107R~
		try
//  	{	Server=new Socket(s,p);                                //~v107R~
    	{                                                          //~v107R~
			Out=new PrintWriter(
				new DataOutputStream(Server.getOutputStream()),true);
			In=new BufferedReader(new InputStreamReader(
			    new DataInputStream(Server.getInputStream())));
		}
		catch (Exception e)
//  	{   return false;                                          //~v107R~
    	{                                                          //~v107I~
            Dump.println(e,"Ajagoc:PartnerFrame:connect");         //~v107I~
            return false;                                          //~v107I~
		}
		PT=new PartnerThread(In,Out,Input,Output,this);
		PT.start();
		Out.println("@@name "+
//  		Global.getParameter("yourname","No Name"));            //~v107R~
    		localDeviceName);                                      //~v107R~
		show();
		return true;
	}

	public boolean connectvia (String server, int port,
		String relayserver, int relayport)
	{                                                              //~v107R~
		return false;	//userelay is off                          //~v107R~
	}

//****************************************************************************//~v107I~
//*from Server.java                                                //~v107I~
//****************************************************************************//~v107I~
//  public void open (Socket server)                               //~v107R~
    public void open (BluetoothSocket server)                      //~v107I~
	{	if (Dump.Y) Dump.println("Starting partner server");       //~@@@1R~
		Server=server;
	    if (Dump.Y) Dump.println("Ajagoc:PartnerFrame:open BTSocket="+Server);//~v107I~
		try
		{	Out=new PrintWriter(
				new DataOutputStream(Server.getOutputStream()),true);
			In=new BufferedReader(new InputStreamReader(
			    new DataInputStream(Server.getInputStream())));
		}
		catch (Exception e)
		{	if (Dump.Y) Dump.println("---> no connection");        //~@@@1R~
			new Message(this,Global.resourceString("Got_no_Connection_"));
			return;
		}
		PT=new PartnerThread(In,Out,Input,Output,this);
		PT.start();
	}


	public void doclose ()
	{	Global.notewindow(this,"partner");	
      try	                                                       //~v107I~
      {                                                            //~v107I~
		Out.println("@@@@end");
		Out.close();
//  	new CloseConnection(Server,In);                            //~v107R~
		if (In!=null)                                              //~v107I~
    		In.close();                                            //~v107I~
        if (Server!=null)                                          //~v107I~
        {                                                          //~v107I~
	      	if (Dump.Y) Dump.println("Ajagoc:PartnerFrame:doclose close BTSocket="+Server);//~v107I~
    		Server.close();                                        //~v107I~
        }                                                          //~v107I~
		super.doclose();
      }                                                            //~v107I~
      catch(Exception e)                                          //~v107I~
      {                                                            //~v107I~
      	Dump.println(e,"Ajagoc:partnerFrame:doclose");             //~v107I~
      }                                                            //~v107I~
	}
//***************************************************************  //~v110R~
//*ReadLine blocks close() so interupt then close               *  //~v110R~
//***************************************************************  //~v110R~
    public void closeStream()                                      //~v110R~
    {                                                              //~v110R~
    	if (PGF!=null)                                             //~v110I~
        	if (PGF.Timer!=null)                                   //~v110I~
            	if (PGF.Timer.isAlive())                          //~v110I~
                {                                                  //~v110I~
				    if (Dump.Y) Dump.println("PartnerFrame Timet Stop");//~v110I~
                	PGF.Timer.stopit();                            //~v110I~
                }                                                  //~v110I~
	    if (Dump.Y) Dump.println("PartnerFrame close Stream");     //~v110R~
        if (PT.isAlive())                                          //~v110R~
        {                                                          //~v110R~
		    if (Dump.Y) Dump.println("PartnerFrame put @@@@end");  //~v110R~
            if (Out!=null)                                         //~v110R~
            {                                                      //~v110R~
                out("@@@@end"); //partnerthread chk this and throw IOException//~v110R~
            }                                                      //~v110R~
        }                                                          //~v110R~
    }                                                              //~v110R~

}

