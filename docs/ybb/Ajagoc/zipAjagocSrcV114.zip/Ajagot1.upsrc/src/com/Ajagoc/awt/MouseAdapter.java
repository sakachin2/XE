package com.Ajagoc.awt;                                                //~1108R~//~1109R~


public abstract class MouseAdapter implements MouseListener {      //+1214I~
    public void mouseClicked(MouseEvent e) {}                      //+1214I~
    public void mousePressed(MouseEvent e) {}                      //+1214I~
    public void mouseReleased(MouseEvent e) {}                     //+1214I~
    public void mouseEntered(MouseEvent e) {}                      //+1214I~
    public void mouseExited(MouseEvent e) {}                       //+1214I~
}                                                                  //+1214I~
