package com.Ajagoc.awt;                                                //~1108R~//~1109R~//~1215I~

public class GridBagConstraints                                    //~1215R~
{                                                                  //~1215I~
    public static final int NONE = 0;                              //~1215R~
    public static final int BOTH = 1;                              //~1215R~
    public static final int HORIZONTAL = 2;                        //~1215R~
    public static final int VERTICAL = 3;                          //~1215R~
    public static final int CENTER = 10;                           //~1215R~
                                                                   //~1215I~
	public int gridx;                                              //~1215I~
	public int gridy;                                              //~1215I~
	public int gridwidth,gridheight,fill,anchor;                   //+1215R~
	public double weightx,weighty;                                 //+1215I~
  	public GridBagConstraints ()                                   //~1215R~
	{                                                              //~1215I~
  	}                                                              //~1215R~
}
