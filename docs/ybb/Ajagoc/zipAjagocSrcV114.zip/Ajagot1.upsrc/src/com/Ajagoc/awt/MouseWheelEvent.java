package com.Ajagoc.awt;                                                //~1108R~//~1109R~

public class MouseWheelEvent                                        //~1212R~//~1213R~
{   
    public static final int WHEEL_BACK_SCROLL=1;                   //~1214I~
    public static final int WHEEL_BLOCK_SCROLL=2;                  //+1214I~
    public int getScrollType()                                     //~1214I~
    {                                                              //~1214I~
        return 0;                                                  //~1214I~
    }                                                              //~1214I~
    public int getWheelRotation()                                  //~1214I~
    {                                                              //~1214I~
        return 0;                                                  //~1214I~
    }                                                              //~1214I~
    public int getScrollAmount()                                   //~1214I~
    {                                                              //~1214I~
        return 0;                                                  //~1214I~
    }                                                              //~1214I~
}//class                                                           //~1212R~
