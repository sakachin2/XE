package com.Ajagoc.awt;                                                //~1108R~//~1109R~
//*for GoFrame:Clipboard process                                   //~1401R~
public class DataFlavor                                            //~1401R~
{                                                                  //~1111I~
	public static DataFlavor stringFlavor=null;                    //+1401R~
}
