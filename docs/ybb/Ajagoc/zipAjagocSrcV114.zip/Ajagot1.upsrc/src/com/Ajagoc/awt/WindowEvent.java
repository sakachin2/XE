package com.Ajagoc.awt;                                            //~1112I~

public class WindowEvent                                           //~1125R~
{                                                                  //~1112I~
	Window window;                                                 //+1516I~
    public WindowEvent()                     //~1115I~             //~1125R~
	{                                                              //~1115I~
    }                                                              //~1115I~
    public WindowEvent(Window Pwindow)                             //+1516I~
	{                                                              //+1516I~
    	window=Pwindow;                                            //+1516I~
    }                                                              //+1516I~
//****************                                                 //~1116I~
}//class                                                           //~1112I~
