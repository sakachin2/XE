//*CID://+dateR~: update#=  81;                                    //~1107R~
//**********************************************************************//~1107I~
package com.Ajagoc;                                         //~1107R~  //~1108R~//~1109R~

//**********************************************************************//~1107I~
public interface AjagoAlertI                                            //~1107R~//~1211R~
{                                                                  //~0914I~
	public int alertButtonAction(int Pbuttonid,int Pitempos);      //+1211R~
}//interface AjagoAlertI                                           //~1211R~
