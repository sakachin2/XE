package com.Ajagoc.awt;                                            //~1112I~

public class Dimension                                             //~1117R~
{                                                                  //~1112I~
	public int height=0,width=0;                                   //~1117R~
    public Dimension()                                        //~1117I~//+1120R~
    {                                                              //~1117I~
    }                                                              //~1117I~
    public Dimension(int Pw,int Ph)                                //+1120I~
    {                                                              //+1120I~
    	height=Ph;                                                 //+1120I~
    	width=Pw;                                                  //+1120I~
    }                                                              //+1120I~
    public void setSize(int Pw,int Ph)                                     //~1117I~
    {                                                              //~1117I~
    	height=Ph;                                                 //~1117I~
    	width=Pw;                                                  //~1117I~
    }                                                              //~1117I~
                        //~1117I~
}//class                                                           //~1112I~
