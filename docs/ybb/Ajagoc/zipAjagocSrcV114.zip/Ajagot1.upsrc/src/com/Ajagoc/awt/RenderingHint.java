package com.Ajagoc.awt;                                                //~1108R~//~1109R~

public class RenderingHint                                         //~1213R~
{   
//*dummy                                                           //~1213I~

}
