//*CID://+v110R~:                             update#=   34;       //~v110R~
//**********************************************************************//~@@@@I~
//1102:130123 bluetooth became unconnectable after some stop operation//~@@@@I~
//**********************************************************************//~@@@@I~
/*
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.Ajagoc.BT;                                             //~@@@@I~

import jagoclient.Dump;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

import com.Ajagoc.AG;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
//import android.util.Log;                                         //~@@@@R~

/**
 * This class does all the work for setting up and managing Bluetooth
 * connections with other devices. It has a thread that listens for
 * incoming connections, a thread for connecting with a device, and a
 * thread for performing data transmissions when connected.
 */
//public class BluetoothChatService {                              //~@@@@R~
public class BTService {                                           //~@@@@I~
    // Debugging
//    private static final String TAG = "BluetoothChatService";
//    private static final boolean D = true;

    // Name for the SDP record when creating server socket
    private static final String NAME = "BluetoothChat";

    // Unique UUID for this application
//  private static final UUID MY_UUID = UUID.fromString("fa87c0d0-afac-11de-8a39-0800200c9a66");//~@@@@R~
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb");//~2C04R~//~@@@@I~

    // Member fields
    private final BluetoothAdapter mAdapter;
    private final Handler mHandler;
    private AcceptThread mAcceptThread;
    private ConnectThread mConnectThread;
//    private ConnectedThread mConnectedThread;                    //~@@@@R~
    private int mState;

    // Constants that indicate the current connection state
    public static final int STATE_NONE = 0;       // we're doing nothing
    public static final int STATE_LISTEN = 1;     // now listening for incoming connections
    public static final int STATE_CONNECTING = 2; // now initiating an outgoing connection
    public static final int STATE_CONNECTED = 3;  // now connected to a remote device
//  public static BluetoothSocket  mConnectedSocket;               //~v110R~
    public BluetoothSocket  mConnectedSocket;                      //~v110R~
    private BluetoothServerSocket mmServerSocket;            //~@@@@I~

    /**
     * Constructor. Prepares a new BluetoothChat session.
     * @param context  The UI Activity Context
     * @param handler  A Handler to send messages back to the UI Activity
     */
//  public BluetoothChatService(Context context, Handler handler) {//~@@@@R~
    public BTService(Context context, Handler handler) {           //~@@@@I~
        mAdapter = BluetoothAdapter.getDefaultAdapter();
        mState = STATE_NONE;
        mHandler = handler;
    }

    /**
     * Set the current state of the chat connection
     * @param state  An integer defining the current connection state
     */
    private synchronized void setState(int state) {
//      if (D) Log.d(TAG, "setState() " + mState + " -> " + state);//~@@@@R~
        if (Dump.Y) Dump.println("setState() " + mState + " -> " + state);//~@@@@I~
        mState = state;

        // Give the new state to the Handler so the UI Activity can update
        mHandler.obtainMessage(BTControl.MESSAGE_STATE_CHANGE, state, -1).sendToTarget();//~@@@@R~
    }

    /**
     * Return the current connection state. */
    public synchronized int getState() {
        return mState;
    }

    /**
     * Start the chat service. Specifically start AcceptThread to begin a
     * session in listening (server) mode. Called by the Activity onResume() */
    public synchronized void start() {
//      if (D) Log.d(TAG, "start");                                //~@@@@R~
        if (Dump.Y) Dump.println("BTService:start");               //~@@@@I~

        // Cancel any thread attempting to make a connection
        if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}

        // Cancel any thread currently running a connection
//        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}//~@@@@R~

        // Start the thread to listen on a BluetoothServerSocket
        if (mAcceptThread == null) {
//          mAcceptThread = new AcceptThread();                    //~@@@@R~
//          mAcceptThread.start();                                 //~@@@@R~
			acceptNext();                                          //~@@@@I~
        }
        setState(STATE_LISTEN);
    }

    /**
     * Start the ConnectThread to initiate a connection to a remote device.
     * @param device  The BluetoothDevice to connect
     */
    public synchronized void connect(BluetoothDevice device) {
//      if (D) Log.d(TAG, "connect to: " + device);                //~@@@@R~
        if (Dump.Y) Dump.println("BTService:connect connect to: " + device);//~@@@@I~

        // Cancel any thread attempting to make a connection
        if (mState == STATE_CONNECTING) {
            if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}
        }

        // Cancel any thread currently running a connection
//        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}//~@@@@R~

        // Start the thread to connect with the given device
        mConnectThread = new ConnectThread(device);
        mConnectThread.start();
        setState(STATE_CONNECTING);
    }

    /**
     * Start the ConnectedThread to begin managing a Bluetooth connection
     * @param socket  The BluetoothSocket on which the connection was made
     * @param device  The BluetoothDevice that has been connected
     */
    public synchronized void connected(BluetoothSocket socket, BluetoothDevice device) {
//      if (D) Log.d(TAG, "connected");                            //~@@@@R~
        if (Dump.Y) Dump.println("BTService:connected");           //~@@@@I~

        // Cancel the thread that completed the connection
        if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}

        // Cancel any thread currently running a connection
//        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}//~@@@@R~

        // Cancel the accept thread because we only want to connect to one device
        if (mAcceptThread != null) {mAcceptThread.cancel(); mAcceptThread = null;}

        // Start the thread to manage the connection and perform transmissions
//        mConnectedThread = new ConnectedThread(socket);          //~@@@@R~
//        mConnectedThread.start();                                //~@@@@R~

        // Send the name of the connected device back to the UI Activity
        mConnectedSocket=socket;  //before sendMessage             //~@@@@I~
        Message msg = mHandler.obtainMessage(BTControl.MESSAGE_DEVICE_NAME);//~@@@@R~
        Bundle bundle = new Bundle();
        bundle.putString(BTControl.DEVICE_NAME, device.getName()); //~@@@@R~
        msg.setData(bundle);
        mHandler.sendMessage(msg);

        setState(STATE_CONNECTED);
    }

    /**
     * Stop all threads
     */
    public synchronized void stop() {
//      if (D) Log.d(TAG, "stop");                                 //~@@@@R~
        if (Dump.Y) Dump.println("BTService:stop");                //~@@@@I~
        if (mConnectThread != null) {mConnectThread.cancel(); mConnectThread = null;}
//        if (mConnectedThread != null) {mConnectedThread.cancel(); mConnectedThread = null;}//~@@@@R~
        if (mAcceptThread != null) {mAcceptThread.cancel(); mAcceptThread = null;}
        setState(STATE_NONE);
    }

//    /**                                                          //~@@@@R~
//     * Write to the ConnectedThread in an unsynchronized manner  //~@@@@R~
//     * @param out The bytes to write                             //~@@@@R~
//     * @see ConnectedThread#write(byte[])                        //~@@@@R~
//     */                                                          //~@@@@R~
//    public void write(byte[] out) {                              //~@@@@R~
//        // Create temporary object                               //~@@@@R~
//        ConnectedThread r;                                       //~@@@@R~
//        // Synchronize a copy of the ConnectedThread             //~@@@@R~
//        synchronized (this) {                                    //~@@@@R~
//            if (mState != STATE_CONNECTED) return;               //~@@@@R~
//            r = mConnectedThread;                                //~@@@@R~
//        }                                                        //~@@@@R~
//        // Perform the write unsynchronized                      //~@@@@R~
//        r.write(out);                                            //~@@@@R~
//    }                                                            //~@@@@R~

    /**
     * Indicate that the connection attempt failed and notify the UI Activity.
     */
    private void connectionFailed() {
        setState(STATE_LISTEN);

        // Send a failure message back to the Activity
        Message msg = mHandler.obtainMessage(BTControl.MESSAGE_TOAST);//~@@@@R~
        Bundle bundle = new Bundle();
        bundle.putString(BTControl.TOAST, "Unable to connect device");//~@@@@R~
        msg.setData(bundle);
        mHandler.sendMessage(msg);
    }

    /**
     * Indicate that the connection was lost and notify the UI Activity.
     */
//  private void connectionLost() {                                //~@@@@R~
    public  void connectionLost() {                                //~@@@@I~
        setState(STATE_LISTEN);
        if (AG.ajagoBT.swDestroy)                                      //~v110I~
            return;                                                //~v110I~

        // Send a failure message back to the Activity
        Message msg = mHandler.obtainMessage(BTControl.MESSAGE_TOAST);//~@@@@R~
        Bundle bundle = new Bundle();
        bundle.putString(BTControl.TOAST, "Device connection was lost");//~@@@@R~
        msg.setData(bundle);
        mHandler.sendMessage(msg);
    }

    /**
     * This thread runs while listening for incoming connections. It behaves
     * like a server-side client. It runs until a connection is accepted
     * (or until cancelled).
     */
    private class AcceptThread extends Thread {
        // The local server socket
//      private final BluetoothServerSocket mmServerSocket;        //~@@@@R~
        private boolean swCancel=false;                            //~@@@@I~

        public AcceptThread() {
            BluetoothServerSocket tmp = null;

            // Create a new listening server socket
            try {
                tmp = mAdapter.listenUsingRfcommWithServiceRecord(NAME, MY_UUID);
            } catch (IOException e) {
//              Log.e(TAG, "listen() failed", e);                  //~@@@@R~
                Dump.println(e,"AcceptThread:listenUsingRfcommWithServiceRecord");//~@@@@I~
                // Send a failure message back to the Activity     //~@@@@I~
                Message msg = mHandler.obtainMessage(BTControl.MESSAGE_TOAST);//~@@@@I~
                Bundle bundle = new Bundle();                      //~@@@@I~
                bundle.putString(BTControl.TOAST, "Accept Failed,Adaptor may be closed,reboot may be required");//~@@@@I~
                msg.setData(bundle);                               //~@@@@I~
                mHandler.sendMessage(msg);                         //~@@@@I~
            }
            mmServerSocket = tmp;
        }

        public void run() {
//          if (D) Log.d(TAG, "BEGIN mAcceptThread" + this);       //~@@@@R~
            if (Dump.Y) Dump.println("AcceptThread:run() BEGIN mAcceptThread" + this);//~@@@@I~
            setName("AcceptThread");
            BluetoothSocket socket = null;

            // Listen to the server socket if we're not connected
            while (mState != STATE_CONNECTED) {
                try {
                    // This is a blocking call and will only return on a
                    // successful connection or an exception
	            	if (Dump.Y) Dump.println("AcceptThread:accept() mmServerSocket="+mmServerSocket.toString());//~v110I~
                    socket = mmServerSocket.accept();
	            	if (Dump.Y) Dump.println("AcceptThread:accept() accepted socket="+socket.toString());//~v110I~
//              } catch (IOException e) {                          //~v110R~
                } catch (Exception e) {                            //~v110I~
//                  Log.e(TAG, "accept() failed", e);              //~@@@@R~
					if (swCancel)                                  //~@@@@I~
                    {                                              //~@@@@I~
	                    if (Dump.Y) Dump.println("AcceptThread:serverSocket accept canceled");//~@@@@I~
                    }                                              //~@@@@I~
                    else                                           //~@@@@I~
                    {                                              //~v110I~
	                    Dump.println(e,"AcceptThread:run accept()");//~@@@@R~
                    }                                              //~v110I~
//                    try {                                        //+v110R~
//                        if (Dump.Y) Dump.println("AcceptThread mmServerSoket close()="+mmServerSocket.toString());//+v110R~
//                        mmServerSocket.close();                  //+v110R~
//                    } catch (Exception ex) {                     //+v110R~
//                          Dump.println(ex,"AcceptThread:Server Socket Close at IOException");//+v110R~
//                    }                                            //+v110R~
                    break;
                }

                // If a connection was accepted
                if (socket != null) {
                    synchronized (BTService.this) {                //~@@@@R~
                        switch (mState) {
                        case STATE_LISTEN:
                        case STATE_CONNECTING:
                            // Situation normal. Start the connected thread.
            				if (Dump.Y)  Dump.println("acceptThread run connected socket="+socket.toString());//~v110I~
                            connected(socket, socket.getRemoteDevice());
                            break;
                        case STATE_NONE:
                        case STATE_CONNECTED:
                            // Either not ready or already connected. Terminate new socket.
                            try {
            				    if (Dump.Y)  Dump.println("acceptThread run connected,but close() by mstate="+mState+",socket="+socket.toString());//~v110I~
                                socket.close();
                            } catch (IOException e) {
//                              Log.e(TAG, "Could not close unwanted socket", e);//~@@@@R~
                                Dump.println(e,"AcceptThread:run Could not close unwanted socket");//~@@@@I~
                            }
                            break;
                        }
                    }
                }
            }
//          if (D) Log.i(TAG, "END mAcceptThread");                //~@@@@R~
            if (Dump.Y) Dump.println("END mAcceptThread");         //~@@@@I~
        }

        public void cancel() {
//          if (D) Log.d(TAG, "cancel " + this);                   //~@@@@R~
            if (Dump.Y) Dump.println("AcceptThread:cancel " + this);//~@@@@I~
            if (Dump.Y) Dump.println("AcceptThread cancel() close() serversocket="+mmServerSocket.toString());//~v110I~
            try {
                swCancel=true;                                     //~@@@@I~
                mmServerSocket.close();
            } catch (IOException e) {
//                Log.e(TAG, "close() of server failed", e);       //~@@@@R~
                  Dump.println(e,"AcceptThread:cancel:close");     //~@@@@I~
            }
        }
    }


    /**
     * This thread runs while attempting to make an outgoing connection
     * with a device. It runs straight through; the connection either
     * succeeds or fails.
     */
    private class ConnectThread extends Thread {
        private final BluetoothSocket mmSocket;
        private final BluetoothDevice mmDevice;
        private boolean swCancel=false;                            //~v110I~

        public ConnectThread(BluetoothDevice device) {
            mmDevice = device;
            BluetoothSocket tmp = null;

            // Get a BluetoothSocket for a connection with the
            // given BluetoothDevice
            try {
                tmp = device.createRfcommSocketToServiceRecord(MY_UUID);
            } catch (IOException e) {
//              Log.e(TAG, "create() failed", e);                  //~@@@@R~
                Dump.println(e,"ConnectThread:createRfcommSocketToServiceRecord");//~@@@@I~
            }
            mmSocket = tmp;
            if (Dump.Y) Dump.println("BTService connectThread connected mmSocket="+mmSocket.toString());//~v110I~
        }

        public void run() {
//          Log.i(TAG, "BEGIN mConnectThread");                    //~@@@@R~
            if (Dump.Y) Dump.println("ConnectThread:BEGIN mConnectThread");//~@@@@I~
            setName("ConnectThread");

            // Always cancel discovery because it will slow down a connection
            mAdapter.cancelDiscovery();

            // Make a connection to the BluetoothSocket
            try {
                // This is a blocking call and will only return on a
                // successful connection or an exception
	            if (Dump.Y) Dump.println("ConnectThread:sonnect() mmSocket="+mmSocket.toString());//~v110I~
                mmSocket.connect();
//          } catch (IOException e) {                              //~v110R~
            } catch (Exception e) {                                //~v110I~
              	if (!swCancel)                                     //~v110I~
                	Dump.println(e,"BTService:ConnectThread:run:connect");//~@@@@I~//~v110R~
                connectionFailed();
                // Close the socket
	            if (Dump.Y) Dump.println("BTService:ConnectThread:mmSocket close()="+mmSocket.toString());//~v110I~
                try {
                    mmSocket.close();
                } catch (IOException e2) {
//                  Log.e(TAG, "unable to close() socket during connection failure", e2);//~@@@@R~
                	Dump.println(e,"BTService:ConnectThread:run:close");//~@@@@I~
                }
                // Start the service over to restart listening mode
//              BTService.this.start();                            //~@@@@R~//~v110R~
                return;
            }

            // Reset the ConnectThread because we're done
            synchronized (BTService.this) {                        //~@@@@R~
                mConnectThread = null;
            }

            // Start the connected thread
            if (Dump.Y)  Dump.println("connectThread run connected socket="+mmSocket.toString());//~v110I~
            connected(mmSocket, mmDevice);
        }

        public void cancel() {
            try {
            	if (Dump.Y) Dump.println("ConnectThread cancel() close socket="+mmSocket.toString());//~v110I~
                swCancel=true;                                     //~v110I~
                mmSocket.close();
            } catch (IOException e) {
//              Log.e(TAG, "close() of connect socket failed", e); //~@@@@R~
                Dump.println(e,"ConnectThread:cancel close()");    //~@@@@I~
            }
        }
    }

    /**
     * This thread runs during a connection with a remote device.
     * It handles all incoming and outgoing transmissions.
     */
//    private class ConnectedThread extends Thread {               //~@@@@R~
//        private final BluetoothSocket mmSocket;                  //~@@@@R~
//        private final InputStream mmInStream;                    //~@@@@R~
//        private final OutputStream mmOutStream;                  //~@@@@R~

//        public ConnectedThread(BluetoothSocket socket) {         //~@@@@R~
//            Log.d(TAG, "create ConnectedThread");                //~@@@@R~
//            mmSocket = socket;                                   //~@@@@R~
//            InputStream tmpIn = null;                            //~@@@@R~
//            OutputStream tmpOut = null;                          //~@@@@R~

//            // Get the BluetoothSocket input and output streams  //~@@@@R~
//            try {                                                //~@@@@R~
//                tmpIn = socket.getInputStream();                 //~@@@@R~
//                tmpOut = socket.getOutputStream();               //~@@@@R~
//            } catch (IOException e) {                            //~@@@@R~
//                Log.e(TAG, "temp sockets not created", e);       //~@@@@R~
//            }                                                    //~@@@@R~

//            mmInStream = tmpIn;                                  //~@@@@R~
//            mmOutStream = tmpOut;                                //~@@@@R~
//        }                                                        //~@@@@R~

//        public void run() {                                      //~@@@@R~
//            Log.i(TAG, "BEGIN mConnectedThread");                //~@@@@R~
//            byte[] buffer = new byte[1024];                      //~@@@@R~
//            int bytes;                                           //~@@@@R~

//            // Keep listening to the InputStream while connected //~@@@@R~
//            while (true) {                                       //~@@@@R~
//                try {                                            //~@@@@R~
//                    // Read from the InputStream                 //~@@@@R~
//                    bytes = mmInStream.read(buffer);             //~@@@@R~

//                    // Send the obtained bytes to the UI Activity//~@@@@R~
//                    mHandler.obtainMessage(BTControl.MESSAGE_READ, bytes, -1, buffer)//~@@@@R~
//                            .sendToTarget();                     //~@@@@R~
//                } catch (IOException e) {                        //~@@@@R~
//                    Log.e(TAG, "disconnected", e);               //~@@@@R~
//                    connectionLost();                            //~@@@@R~
//                    break;                                       //~@@@@R~
//                }                                                //~@@@@R~
//            }                                                    //~@@@@R~
//        }                                                        //~@@@@R~

        /**
         * Write to the connected OutStream.
         * @param buffer  The bytes to write
         */
//        public void write(byte[] buffer) {                       //~@@@@R~
//            try {                                                //~@@@@R~
//                mmOutStream.write(buffer);                       //~@@@@R~

//                // Share the sent message back to the UI Activity//~@@@@R~
//                mHandler.obtainMessage(BTControl.MESSAGE_WRITE, -1, -1, buffer)//~@@@@R~
//                        .sendToTarget();                         //~@@@@R~
//            } catch (IOException e) {                            //~@@@@R~
//                Log.e(TAG, "Exception during write", e);         //~@@@@R~
//            }                                                    //~@@@@R~
//        }                                                        //~@@@@R~

//        public void cancel() {                                   //~@@@@R~
//            try {                                                //~@@@@R~
//                mmSocket.close();                                //~@@@@R~
//            } catch (IOException e) {                            //~@@@@R~
//                Log.e(TAG, "close() of connect socket failed", e);//~@@@@R~
//            }                                                    //~@@@@R~
//        }                                                        //~@@@@R~
//    }                                                            //~@@@@R~
//***************************************************************************//~@@@@I~
	public static InputStream getBTInputStream(BluetoothSocket Psocket)//~@@@@I~
    {                                                              //~@@@@I~
    	InputStream s=null;                                        //~@@@@I~
		try                                                        //~@@@@I~
    	{                                                          //~@@@@I~
			s=Psocket.getInputStream();                            //~@@@@I~
		}                                                          //~@@@@I~
		catch (Exception e)                                        //~@@@@I~
		{                                                          //~@@@@I~
        	Dump.println(e,"getBTInputStream");                    //~@@@@I~
		}                                                          //~@@@@I~
        return s;                                                  //~@@@@I~
    }                                                              //~@@@@I~
//***************************************************************************//~@@@@I~
	public static OutputStream getBTOutputStream(BluetoothSocket Psocket)//~@@@@I~
    {                                                              //~@@@@I~
    	OutputStream s=null;                                       //~@@@@I~
		try                                                        //~@@@@I~
    	{                                                          //~@@@@I~
			s=Psocket.getOutputStream();                           //~@@@@I~
		}                                                          //~@@@@I~
		catch (Exception e)                                        //~@@@@I~
		{                                                          //~@@@@I~
        	Dump.println(e,"getBTOutputStream");                   //~@@@@I~
		}                                                          //~@@@@I~
        return s;                                                  //~@@@@I~
    }                                                              //~@@@@I~
//***************************************************************************//~@@@@I~
	public boolean acceptNext()                                    //~@@@@R~
    {                                                              //~@@@@I~
        if (mAcceptThread == null) {                               //~@@@@I~
            mAcceptThread = new AcceptThread();                    //~@@@@I~
    	  	if (mmServerSocket==null)                              //~@@@@I~
            	mAcceptThread =null;                               //~@@@@I~
            else                                                   //~@@@@I~
            	mAcceptThread.start();                             //~@@@@R~
            return true;  //started thread                         //~@@@@I~
        }                                                          //~@@@@I~
        return false;	//now alive                                //~@@@@I~
    }                                                              //~@@@@I~
}
