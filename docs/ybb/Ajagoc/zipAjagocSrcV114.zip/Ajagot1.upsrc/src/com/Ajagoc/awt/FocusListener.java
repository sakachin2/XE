package com.Ajagoc.awt;                                                //~1108R~//~1109R~//+1213I~
public interface FocusListener/* extends EventListener*/           //~1213I~
{                                                                  //~1213I~
    public void focusGained(FocusEvent e);                         //~1213I~
    public void focusLost(FocusEvent e);                           //~1213I~
}                                                                  //~1213I~
