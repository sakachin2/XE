//*CID://+v108R~:                             update#=    2;       //~v108I~
//*************************************************************************//~v108I~
//1083:121215 deadlock                                             //~v108I~
//            thread16:syncrh allsend() is called by "Who" button push//~v108I~
//            thread1:"Redresh" button call sync refresh()---wait MainThread//~v108I~
//            thread16:component:showlist() execute runOnUiThread-->wait MainThread then blocked//~v108I~
//*************************************************************************//~v108I~
package jagoclient.igs.games;

import jagoclient.Global;
import jagoclient.dialogs.Help;
import jagoclient.gui.ButtonAction;
import jagoclient.gui.CloseFrame;
import jagoclient.gui.CloseListener;
import jagoclient.gui.MenuItemAction;
import jagoclient.gui.MyMenu;
import jagoclient.gui.Panel3D;
//import jagoclient.gui.MenuItemAction;
import jagoclient.gui.MyLabel;
//import jagoclient.gui.MyMenu;
import jagoclient.gui.MyPanel;
//import jagoclient.gui.Panel3D;
import jagoclient.igs.ConnectionFrame;
import jagoclient.igs.IgsStream;

//import java.awt.BorderLayout;                                    //~1115R~
//import java.awt.Color;                                           //~1115R~
//import java.awt.Menu;                                            //~1115R~
//import java.awt.MenuBar;                                         //~1115R~
//import java.awt.MenuItem;                                        //~1115R~
//import java.awt.Panel;                                           //~1115R~
//import java.awt.PopupMenu;                                       //~1115R~
import java.io.PrintWriter;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.Ajagoc.AjagoView;
import com.Ajagoc.awt.BorderLayout;
import com.Ajagoc.awt.Color;
import com.Ajagoc.awt.Menu;
import com.Ajagoc.awt.MenuBar;
import com.Ajagoc.awt.MenuItem;
import com.Ajagoc.awt.Panel;
import com.Ajagoc.awt.PopupMenu;
import com.Ajagoc.rene.viewer.Lister;
import com.Ajagoc.rene.viewer.SystemLister;

import rene.util.list.ListClass;
import rene.util.list.ListElement;
import rene.util.parser.StringParser;
import rene.util.sort.Sorter;
//import rene.viewer.Lister;
//import rene.viewer.SystemLister;                                 //~1220R~

/**
This frame displays the games on the server. It is 
opened by a GamesDistributor. To sort the games it
uses the GamesObject class, which is a SortObject
implementation and can be sorted via the Sorter
quicksort algorithm.
@see jagoclient.sort.Sorter
*/

public class GamesFrame extends CloseFrame implements CloseListener
{	IgsStream In;
	PrintWriter Out;
	Lister T;
	ConnectionFrame CF;
	GamesDistributor GD;
	ListClass L;
	boolean Closed=false;
	int LNumber;
    private Lock lock=new ReentrantLock();                         //~v108I~
	
	public GamesFrame (ConnectionFrame cf, PrintWriter out, IgsStream in)
	{	super(Global.resourceString("_Games_"));
		cf.addCloseListener(this);
		In=in;
		Out=out;
		MenuBar mb=new MenuBar();
		setMenuBar(mb);
		Menu m=new MyMenu(Global.resourceString("Options"));
		m.add(new MenuItemAction(this,Global.resourceString("Close")));
		mb.add(m);
		Menu help=new MyMenu(Global.resourceString("Help"));
		help.add(new MenuItemAction(this,Global.resourceString("About_this_Window")));
		mb.add(help);
		setLayout(new BorderLayout());
		T=Global.getParameter("systemlister",false)?new SystemLister():new Lister();
		T.setFont(Global.Monospaced);
		T.setBackground(Global.gray);
		T.setText(Global.resourceString("Loading"));
		add("Center",T);
		Panel p=new MyPanel();
		p.add(new ButtonAction(this,Global.resourceString("Observe")));
		p.add(new ButtonAction(this,Global.resourceString("Peek")));
		p.add(new ButtonAction(this,Global.resourceString("Status")));
		p.add(new MyLabel(" "));
		p.add(new ButtonAction(this,Global.resourceString("Refresh")));
		p.add(new ButtonAction(this,Global.resourceString("Close")));
		add("South",new Panel3D(p));
		CF=cf;
		GD=null;
		seticon("igames.gif");
		PopupMenu pop=new PopupMenu();
		addpop(pop,Global.resourceString("Observe"));
		addpop(pop,Global.resourceString("Peek"));
		addpop(pop,Global.resourceString("Status"));
		if (T instanceof Lister) T.setPopupMenu(pop);
	}
	
	public void addpop (PopupMenu pop, String label)
	{	MenuItem mi=new MenuItemAction(this,label,label);
		pop.add(mi);
	}
	
	public void doAction (String o)
	{	if (Global.resourceString("Refresh").equals(o))
		{	refresh();
		}
		else if (Global.resourceString("Peek").equals(o))
		{	String s=T.getSelectedItem();
			if (s==null) return;
			StringParser p=new StringParser(s);
			p.skipblanks();
			if (!p.skip("[")) return;
			p.skipblanks();
			if (!p.isint()) return;
			CF.peek(p.parseint(']'));
		}
		else if (Global.resourceString("Status").equals(o))
		{	String s=T.getSelectedItem();
			if (s==null) return;
			StringParser p=new StringParser(s);
			p.skipblanks();
			if (!p.skip("[")) return;
			p.skipblanks();
			if (!p.isint()) return;
			CF.status(p.parseint(']'));
		}
		else if (Global.resourceString("Observe").equals(o))
		{	String s=T.getSelectedItem();
			if (s==null) return;
			StringParser p=new StringParser(s);
			p.skipblanks();
			if (!p.skip("[")) return;
			p.skipblanks();
			if (!p.isint()) return;
			CF.observe(p.parseint(']'));
		}
		else if (Global.resourceString("About_this_Window").equals(o))
		{	new Help("games");
		}
		else super.doAction(o);
	}

//	public synchronized boolean close ()                           //~v108R~
//	{	if (GD!=null) GD.unchain();                                //~v108R~
    public boolean close ()                                        //~v108I~
	{                                                              //~v108I~
      if (lock.tryLock())                                          //~v108I~
      {                                                            //~v108I~
       try                                                         //~v108I~
       {                                                           //~v108I~
		if (GD!=null) GD.unchain();                                //~v108I~
		CF.Games=null;
		CF.removeCloseListener(this);
		Closed=true;
		Global.notewindow(this,"games");		
		return true;
       }finally{lock.unlock();}                                    //~v108I~
      }                                                            //~v108I~
      else                                                         //~v108I~
      {                                                            //~v108I~
        AjagoView.lockContention("games-close");                   //~v108I~
        return false;                                              //~v108I~
      }                                                            //~v108I~
	}

	/**
	Opens a new GamesDistributor to receive the games from the
	server. and asks the server to send the games.
	*/
//  public synchronized void refresh ()                            //~v108R~
//  {	L=new ListClass(); LNumber=0;                              //~v108I~
    public void refresh ()                                         //~v108I~
	{                                                              //~v108R~
      if (lock.tryLock())                                          //~v108I~
      {                                                            //~v108I~
       try                                                         //~v108I~
       {                                                           //~v108I~
		L=new ListClass(); LNumber=0;                              //~v108I~
		T.setText(Global.resourceString("Loading"));
		if (GD!=null) GD.unchain();
		GD=new GamesDistributor(In,this);
		Out.println("games");
       }finally{lock.unlock();}                                    //~v108I~
      }                                                            //~v108I~
      else                                                         //~v108I~
      {                                                            //~v108I~
        AjagoView.lockContention("Games-refresh");                 //~v108I~
      }                                                            //~v108I~
	}

//  public synchronized void receive (String s)                    //~v108R~
//  {	if (Closed) return;                                        //~v108R~
    public void receive (String s)                                 //~v108I~
  	{                                                              //~v108I~
      if (lock.tryLock())                                          //~v108I~
      {                                                            //~v108I~
       try                                                         //~v108I~
       {                                                           //~v108I~
  		if (Closed) return;                                        //~v108I~
	    L.append(new ListElement(s)); LNumber++;
	    if (LNumber==1) T.setText(Global.resourceString("Receiving"));
       }finally{lock.unlock();}                                    //~v108I~
      }                                                            //~v108I~
      else                                                         //~v108I~
      {                                                            //~v108I~
        AjagoView.lockContention("Games-receive");                 //~v108I~
      }                                                            //~v108I~
	}

	/**
	When the distributor has all games, it calls allsended
	and the sorting will start.
	*/
//  public synchronized void allsended ()                          //~v108R~
//  {	if (GD!=null) GD.unchain();                                //~v108R~
  	public void allsended ()                                       //+v108R~
	{                                                              //~v108I~
      if (lock.tryLock())                                          //~v108I~
      {                                                            //~v108I~
       try                                                         //~v108I~
       {                                                           //~v108I~
		if (GD!=null) GD.unchain();                                //~v108I~
	    if (Closed) return;
		ListElement p=L.first();
		int i,n=0;
		while (p!=null)
		{	n++;
			p=p.next();
		}
		if (n>3)
		{	GamesObject v[]=new GamesObject[n-1];
			p=L.first().next();
			for (i=0; i<n-1; i++)
			{	v[i]=new GamesObject((String)p.content());
				p=p.next();
			}
			Sorter.sort(v);
			T.setText("");
			T.appendLine0(" "+(String)L.first().content());
			Color FC=Color.green.darker().darker();
			for (i=0; i<n-1; i++)
			{	T.appendLine0(v[i].game(),v[i].friend()?
					FC:Color.black);
			}
			T.doUpdate(false);
		}
		else
		{	p=L.first();
			while (p!=null)
			{	T.appendLine((String)p.content());
				p=p.next();
			}
			T.doUpdate(false);
		}
       }finally{lock.unlock();}                                    //~v108I~
      }                                                            //~v108I~
      else                                                         //~v108I~
      {                                                            //~v108I~
        AjagoView.lockContention("Games-allsend");                 //~v108I~
      }                                                            //~v108I~
	}
	
	public void isClosed ()
	{	if (Global.getParameter("menuclose",true)) setMenuBar(null);
		setVisible(false); dispose();
	}
}
