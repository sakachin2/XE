package jagoclient.gui;

import com.Ajagoc.awt.MenuItem;

import jagoclient.Global;

//import java.awt.MenuItem;

//import com.Ajagoc.awt.Menu;

/**
A menu item with a specified font.
*/

public class MenuItemAction extends MenuItem                       //~1122R~
{   ActionTranslator AT;
	public MenuItemAction (DoActionListener c, String s, String name)
    {   super(s);
	    addActionListener(AT=new ActionTranslator(c,name));
        setFont(Global.SansSerif);
    }
    public MenuItemAction (DoActionListener c, String s)
    {	this(c,s,s);
    }
    public void setString (String s)
    {	AT.setString(s);
    }
}
