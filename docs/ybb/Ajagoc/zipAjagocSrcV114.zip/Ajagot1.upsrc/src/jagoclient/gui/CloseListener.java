package jagoclient.gui;

/**
An event listener interface for the CloseFrame.
*/

public interface CloseListener
{	/** called, when the client frame closes */
	public void isClosed ();
}