//*CID://+1B0cR~:                             update#=    2;       //+1B0cR~
//******************************************************************//~1B06I~
//1B0c 130429 Encoding support for partner connection              //+1B0cI~
//1B06 130428 Warning userrelay option is on when partner connection failed//~1B06I~
//******************************************************************//~1B06I~
package jagoclient.partner;

import com.Ajagoc.AG;
import com.Ajagoc.R;

import jagoclient.Global;
import jagoclient.dialogs.Message;
import jagoclient.partner.partner.Partner;

/**
A thread, which will try to connect to a go partner.
If it is successfull, a Partner Frame will open.
Otherwise, an error message will appear.
*/

public class ConnectPartner extends Thread
{	Partner P;
	PartnerFrame PF;
	public ConnectPartner (Partner p, PartnerFrame pf)
	{	P=p; PF=pf;
		start();
	}
	public void run ()
	{	P.Trying=true;
		if (Global.getParameter("userelay",false))
		{	if (!PF.connectvia(P.Server,P.Port,
				Global.getParameter("relayserver","localhost"),
				Global.getParameter("relayport",6971)))
			{	PF.setVisible(false); PF.dispose();
				new Message(Global.frame(),
//  				Global.resourceString("No_connection_to_")+P.Server);//~1B06R~
    				Global.resourceString("No_connection_to_")+P.Server+"\n"//~1B06I~
                    +AG.resource.getString(R.string.WarningUseRelay));//~1B06I~
				try
				{	sleep(10000);
				}
				catch (Exception e)
				{	P.Trying=false;
				}
			}
		}
//  	else if (!PF.connect(P.Server,P.Port))                     //+1B0cR~
    	else if (!PF.connect(P.Server,P.Port,P.Encoding))          //+1B0cI~
		{	PF.setVisible(false); PF.dispose();
			new Message(Global.frame(),
				Global.resourceString("No_connection_to_")+P.Server);
			try
			{	sleep(10000);
			}
			catch (Exception e)
			{	P.Trying=false;
			}
		}
		P.Trying=false;
	}
}

