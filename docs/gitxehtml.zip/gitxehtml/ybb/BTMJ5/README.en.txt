(UTF8 encoding)
*********************************************************************************************
Japanese style Mahjong game to play among your friends.
No specific server machine is required.
*****
I suppose you are familiar to rule and operation of Japanese style Mahjong.
Any local "Yaku"(winning pattern) is acceptable
 because winner can claim the value of winning hand.
"Check validity of winning hand" is optional, so "Chombo" by mistaken Ron may occur.
Rule of "Yakitori", "Wareme" and "Tobi" is optional.
From 2 to 4 players can play game. Suspend and resume is supported.
Device is required portrait width 600 pixels over and 800 pixels is recomended.
Bluetooth(legacy mode) and Wifi-Direct are supported for wireless connection.

Please send your suggestion or bug reports to mail:sakachin2@yahoo.co.jp

*********************************************************************************************
V1.02 : 2020/05/09
        .(Bug)Reconnection fails if rule was changed at application restart.
        .BGM option added.
V1.01 : 2020/04/11 (1st release)
