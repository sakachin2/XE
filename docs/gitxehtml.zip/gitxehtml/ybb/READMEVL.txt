Contains following files

  xelnx%xever1%.tgz           :binary compiled on FC5
  gxe-%xever2%.tar.gz         :source package
                                 To build:   tar -xvf  tgzfile
                                             ./configure  
                                             ./make       
                                             ./make install  by root permission (install to /usr/local/bin)
                                 See README when ./configure failed(missing library)
