Contains following files

  xewin%xever1%.zip           :binary compiled by VC6
  xewinu%xever1%.zip          :UTF8 version: binary compiled by VC6
