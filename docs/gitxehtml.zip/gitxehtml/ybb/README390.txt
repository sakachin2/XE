Contains following files(xe on S/390(32bit))

  xe390-%xever1%.tgz          :binary compiled on linex on Hercules emulator(xe console version only)
  xe390-%xever2%.tar.gz       :source package(make console version only)
                                 To build:   tar -xvf  tgzfile
                                             ./configure  
                                             ./make       
                                             ./make install  (install to /usr/local/bin)
