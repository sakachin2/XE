//dummy for ncurses tparm compile option
