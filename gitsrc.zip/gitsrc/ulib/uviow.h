//*CID://+v5m7R~:                             update#=   14;       //+v5m7I~
//******************************************************           //+v5m7I~
//*uviow.h for windows                                             //+v5m7I~
//******************************************************           //+v5m7I~
//v5m7:080204 move internal function to header                     //+v5m7I~
//******************************************************           //+v5m7I~
#ifdef W32                                                         //+v5m7M~
 	#ifndef WXE                                                    //+v5m7M~
		int uvio_setinitwindowpos(CONSOLE_SCREEN_BUFFER_INFO *Ppcsbi,int Pwinh);//+v5m7M~
	#endif                                                         //+v5m7M~
#endif                                                             //+v5m7M~
