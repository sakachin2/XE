//CID://+v059R~:                                                   //~v059I~
//***************************************************************//~5124I~
//v059:970201:use unsigned int for UINT                            //+v059M~
//***************************************************************  //~v059I~
//* uabend                                                      //~5124I~
//* INPUT      :                                                //~5124I~
//      p1:abend code                                           //~5124I~
//      p2:abend information-1                                  //~5124I~
//      p3:abend information-2                                  //~5124I~
//      p4:abend information-3                                  //~5124I~
//*****************************************************************//~5124I~
//*****************************************************************//~v059I~
void uabend(unsigned int perrno,unsigned long p1,unsigned long p2,unsigned long p3);//+v059I~
