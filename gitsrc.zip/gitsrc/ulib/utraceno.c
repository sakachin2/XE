//CID://+v57vR~:                                                   //~v57vR~
//***********************************************************************//~v026I~
//* utrace.c                                                       //~v022R~
//***********************************************************************
//v57v:030126 move utracepnop to another mdule for DOS memory shortage//~v57vI~
//***********************************************************************

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>                                             //~6203I~
void utraceno(void)                                                //+v57vR~
{                                                                  //~v57vI~
    return;                                                        //~v57vI~
}//utraceno                                                        //+v57vR~
void utracepnop(char *Pfmt,...)                                    //~v041I~
{                                                                  //~v041I~
    return;                                                        //~v041I~
}//utracepnop                                                      //~v041I~
