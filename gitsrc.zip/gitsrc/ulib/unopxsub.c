//CID://+v7arR~:       update#= 294                                //~v7arR~
//*************************************************************
//define not used function to avoid link err of xsub               //~v7arI~
//*************************************************************
#include <stdio.h>
//*******************************************************
#include <ulib.h>                                                  //~v022R~
//********************************************************************///~v7ajI~
int uvioGetCursorWidth(int Popt,ULONG Pucs)                        //~v7agI~
{                                                                  //~v7agI~
    return 0;                                                     //~v7agI~//~v7arR~
}//uvioGetCursorWidth                                              //~v7agI~
int dummyCall()                                                    //~v7arI~
{                                                                  //~v7arI~
	return uvioGetCursorWidth(0,0);                                //+v7arR~
}                                                                  //~v7arI~
