//*CID://+v5nxR~:                             update#=   36;       //~v5n8R~//+v5nxI~
//******************************************************           //+v5nxI~
//*utils.h                                                         //+v5nxI~
//******************************************************           //+v5nxI~
//v5nx:081129 avoid redundant link; utrace:no MTTRACE; split to utils.c for independent usage(no ar to user.lib)//+v5nxI~
//******************************************************           //+v5nxI~
void *utils_timeedit(unsigned char *Ppatern,void *Pout);           //+v5nxI~
