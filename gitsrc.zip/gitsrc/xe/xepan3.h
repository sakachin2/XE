//*CID://+v07aR~:**                                                //+v07aI~
//**************************************************************** //+v07aI~
//xepan3.h
//**************************************************************** //+v07aM~
//v07a:960615:allow dup key assign to differrent function for only on of assigned key//+v07aI~
//            color option-2                                       //+v07aI~
//              -field next value function for color register field//+v07aI~
//**************************************************************** //+v07aM~
//**************************************************               //+v07aI~
//*paninvalidfld                                                   //+v07aI~
//*parm1: client work element                                      //+v07aI~
//*rc   :4                                                         //+v07aI~
//**************************************************               //+v07aI~
int  paninvalidfld(PUCLIENTWE Ppcw);                               //+v07aI~
